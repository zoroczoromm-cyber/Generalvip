<?php

$servername = "localhost";
$username = "unjovagf_mda";
$password = "75Pm74Mtz2sRy9gD6tMf";
$dbname = "unjovagf_mda";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>