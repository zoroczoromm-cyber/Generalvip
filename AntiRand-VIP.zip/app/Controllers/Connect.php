<?php

namespace App\Controllers;

use App\Models\KeysModel;

class Connect extends BaseController
{
    protected $model, $game, $uKey, $sDev;

    public function __construct()
    {
        include('conn.php');

        $sql1 = "select * from onoff where id=11";
        $result1 = mysqli_query($conn, $sql1);
        $userDetails1 = mysqli_fetch_assoc($result1);

        $this->model = new KeysModel();

        $this->maintenance = ($userDetails1['status'] == 'off');

        $this->staticWords = "Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E";
    }

    public function index()
    {
        $blacklistedAgents = [
            'HttpCanary', 'MitM', 'Packet Capture', 'PostmanRuntime', 
            'Fiddler', 'Charles', 'BurpSuite', 'Wireshark'
        ];

        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';

        foreach ($blacklistedAgents as $agent) {
            if (stripos($userAgent, $agent) !== false) {
                return $this->response->setJSON([
                    'status' => false,
                    'reason' => 'Access Denied'
                ]);
            }
        }

        if ($this->request->getPost()) {
            return $this->index_post();
        } else {
            return "<h1><strong><center><font size='10' color='red' face='arial'><marquee  direction='right' scrollamount='15' ><br>Hey Boi What are you looking for?? <br> Need Full Fixed panel file <br>  DM on AntiRand @RRGRGRR</marquee></font></center></strong></h1>";

        }
    }

    public function index_post()
    {
        $blacklistedAgents = [
            'HttpCanary', 'MitM', 'Packet Capture', 'PostmanRuntime', 
            'Fiddler', 'Charles', 'BurpSuite', 'Wireshark'
        ];

        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';

        foreach ($blacklistedAgents as $agent) {
            if (stripos($userAgent, $agent) !== false) {
                return $this->response->setJSON([
                    'status' => false,
                    'reason' => 'Access Denied'
                ]);
            }
        }

        $isMT = $this->maintenance;
        $game = $this->request->getPost('game');
        $uKey = $this->request->getPost('user_key');
        $sDev = $this->request->getPost('serial');

        $form_rules = [
            'game' => 'required|alpha_dash',
            'user_key' => 'required|alpha_numeric|min_length[1]|max_length[36]',
            'serial' => 'required|alpha_dash'
        ];

        if (!$this->validate($form_rules)) {
            return $this->response->setJSON([
                'status' => false,
                'reason' => "call @RRGRGRR"
            ]);
        }

        if ($isMT) {
            include('conn.php');

            $sql1 = "select * from onoff where id=11";
            $result1 = mysqli_query($conn, $sql1);
            $userDetails1 = mysqli_fetch_assoc($result1);

            return $this->response->setJSON([
                'status' => false,
                'reason' => $userDetails1['myinput']
            ]);
        }

        if (!$game || !$uKey || !$sDev) {
            return $this->response->setJSON([
                'status' => false,
                'reason' => 'call @RRGRGRR'
            ]);
        }

        $time = new \CodeIgniter\I18n\Time;
        $model = $this->model;
        $findKey = $model->getKeysGame(['user_key' => $uKey, 'game' => $game]);

        if ($findKey) {
            if ($findKey->status != 1) {
                return $this->response->setJSON([
                    'status' => false,
                    'reason' => ''
                ]);
            }

            $id_keys = $findKey->id_keys;
            $duration = $findKey->duration;
            $expired = $findKey->expired_date;
            $max_dev = $findKey->max_devices;
            $devices = $findKey->devices;

            function checkDevicesAdd($serial, $devices, $max_dev)
            {
                $lsDevice = explode(",", $devices);
                $cDevices = isset($devices) ? count($lsDevice) : 0;
                $serialOn = in_array($serial, $lsDevice);

                if ($serialOn) {
                    return true;
                } elseif ($cDevices < $max_dev) {
                    array_push($lsDevice, $serial);
                    $setDevice = implode(",", array_unique($lsDevice));
                    return ['devices' => $setDevice];
                } else {
                    return false;
                }
            }

            if (!$expired) {
                $setExpired = $time::now()->addDays($duration);
                $model->update($id_keys, ['expired_date' => $setExpired]);
                $data['status'] = true;
            } else {
                if ($time::now()->isBefore($expired)) {
                    $data['status'] = true;
                } else {
                    return $this->response->setJSON([
                        'status' => false,
                        'reason' => 'call @RRGRGRR'
                    ]);
                }
            }

            if ($data['status']) {
                include('conn.php');

                $sql2 = "select * from modname where id=1";
                $result2 = mysqli_query($conn, $sql2);
                $userDetails2 = mysqli_fetch_assoc($result2);

                $sql3 = "select * from _ftext where id=1";
                $result3 = mysqli_query($conn, $sql3);
                $userDetails3 = mysqli_fetch_assoc($result3);

                $devicesAdd = checkDevicesAdd($sDev, $devices, $max_dev);
                if ($devicesAdd) {
                    if (is_array($devicesAdd)) {
                        $model->update($id_keys, $devicesAdd);
                    }

                    $expiry = $findKey->expired_date ?? $time::now()->addDays($duration);
                    
                    return $this->response->setJSON([
                        'status' => true,
                        'data' => [
                            'SLOT' => $max_dev,
                            'EXP' => $expiry,
                            'modname' => $userDetails2['modname'],
                            'mod_status' => $userDetails3['_status'],
                            'credit' => $userDetails3['_ftext'],
                            'token' => md5("$game-$uKey-$sDev-$this->staticWords"),
                            'key' => $id_keys,
                            'rng' => $time->getTimestamp()
                        ]
                    ]);
                } else {
                    return $this->response->setJSON([
                        'status' => false,
                        'reason' => 'Max-Device'
                    ]);
                }
            }
        } else {
            return $this->response->setJSON([
                'status' => false,
                'reason' => 'call @RRGRGRR'
            ]);
        }
    }
}
