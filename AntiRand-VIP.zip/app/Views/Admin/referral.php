<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<style>
  html,body { height:100%; margin:0; }
  #particles-js {
    position: fixed;
    top:0; left:0; right:0; bottom:0;
    width:100%; height:100%;
    background-color:#0d1117; 
    z-index: -1;
  }
  
.card { background:rgba(22,27,34,0.85); border:1px solid rgba(88,166,255,0.3); border-radius:12px; color:#e6edf3; }
.card-header { background:rgba(88,166,255,0.1); border-bottom:1px solid rgba(88,166,255,0.3); color:#58a6ff; font-weight:bold; text-shadow:0 0 6px #58a6ff; }
table.table { color:#e6edf3 !important; }
table.table thead th { background:rgba(88,166,255,0.12) !important; color:#58a6ff !important; text-shadow:0 0 6px #58a6ff; }
table.table tbody tr:nth-child(even) { background:rgba(88,166,255,0.05) !important; }
table.table tbody tr:nth-child(odd) { background:rgba(22,27,34,0.6) !important; }
table.table tbody tr:hover { background:rgba(88,166,255,0.15) !important; }

.dashboard-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:14px; margin-bottom:20px; }
.widget { background:rgba(22,27,34,0.88); border:1px solid rgba(88,166,255,0.25); border-radius:12px; padding:16px; text-align:center; box-shadow:0 0 14px rgba(0,0,0,0.3); }
.widget svg { width:32px; height:32px; margin-bottom:6px; fill:#58a6ff; }
.widget .title { color:#58a6ff; font-weight:600; font-size:14px; margin-bottom:4px; }
.widget .val { font-size:1.2rem; font-weight:700; color:#fff; }
</style>
<?= $this->include('Layout/msgStatus') ?>
<div id="particles-js"></div>
<div class="row justify-content-center pt-3">
  <div class="row">
    <div class="col-lg-12">
      
    </div>
<div class="content position-relative" style="z-index:1;">
    <div class="col-lg-4 mb-3">
      <div class="card">
        <div class="card-header p-3"><i class="bi bi-gear"></i> Generate <?= $title ?></div>
        <div class="card-body">
          <?= form_open() ?>
            <div class="form-group mb-3">
              <label for="set_saldo" class="fw-bold">Set saldo</label>
              <div class="input-group mt-2">
                <span class="input-group-text bg-dark text-info border-info"><i class="bi bi-currency-dollar"></i></span>
                <input type="number" class="form-control bg-dark text-light border-info" name="set_saldo" id="set_saldo" value="5">
              </div>
            </div>
            <div class="form-group">
              <button type="submit" class="btn btn-outline-info w-100">
                <i class="bi bi-plus-circle"></i> Create Code
              </button>
            </div>
          <?= form_close() ?>
        </div>
      </div>
    </div>

    <div class="col-lg-8 mb-3">
      <div class="dashboard-grid">
        <div class="widget">
          <svg viewBox="0 0 24 24"><path d="M12 3L2 9l10 6 10-6-10-6z"/></svg>
          <div class="title">Total Codes</div>
          <div class="val"><?= isset($total_code) ? esc($total_code) : 0 ?></div>
        </div>
        <div class="widget">
          <svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12 3.41 13.41 9 19l12-12-1.41-1.41z"/></svg>
          <div class="title">Used</div>
          <div class="val"><?= $userAll ?? 0 ?></div>
        </div>
        <div class="widget">
          <svg viewBox="0 0 24 24"><path d="M20 6H4v12h16V6z"/></svg>
          <div class="title">Unused</div>
          <div class="val"><?= $userAll ?? 0 ?></div>
        </div>
        <div class="widget">
          <svg viewBox="0 0 24 24"><path d="M12 12c2.2 0 4-1.8 4-4s-1.8-4-4-4-4 1.8-4 4 1.8 4 4 4zm0 2c-2.7 0-8 1.3-8 4v2h16v-2c0-2.7-5.3-4-8-4z"/></svg>
          <div class="title">Users</div>
          <div class="val"><?= $userAll ?? 0 ?></div>
        </div>
      </div>
    </div>
  </div>
</div>
<?= $this->endSection() ?>


<?= $this->section('js') ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js") ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js") ?>
<script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
<script>
  particlesJS("particles-js", {
    "particles": {
      "number": { "value": 100, "density": { "enable": true, "value_area": 800 } },
      "color": { "value": "#0ff" },
      "shape": { "type": "circle" },
      "opacity": { "value": 0.5 },
      "size": { "value": 3, "random": true },
      "line_linked": {
        "enable": true,
        "distance": 150,
        "color": "#0ff",
        "opacity": 0.4,
        "width": 1
      },
      "move": { "enable": true, "speed": 2 }
    },
    "interactivity": {
      "events": { "onhover": { "enable": true, "mode": "grab" } },
      "modes": { "grab": { "distance": 140, "line_linked": { "opacity": 1 } } }
    },
    "retina_detect": true
  });
</script>
<?= $this->endSection() ?>