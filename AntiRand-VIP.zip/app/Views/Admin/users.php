<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<style>
  html,body { height:100%; margin:0; }
  #particles-js {
    position: fixed;
    top:0; left:0; right:0; bottom:0;
    width:100%; height:100%;
    background-color:#0d1117; 
    z-index: -1;
  }

  .content {
    position: relative;
    z-index: 1;
    color: #ffffff;
    font-family: sans-serif;
    padding: 2rem;
  }

  .card {
    background-color: rgba(22, 27, 34, 0.85);
    border: 1px solid rgba(88, 166, 255, 0.2);
    border-radius: 10px;
    backdrop-filter: blur(6px);
    color: #ffffff;
  }

  .card-header {
    background: linear-gradient(90deg, #0d1117, #1f2a37);
    border-bottom: 1px solid rgba(88, 166, 255, 0.3);
    font-weight: 600;
    letter-spacing: 0.5px;
    color: #ffffff;
  }

  .card-body,
  .list-group-item {
    background: transparent !important;
    color: #ffffff;
  }

  .bg-primary {
    background: rgba(88, 166, 255, 0.15) !important;
    color: #58a6ff !important;
    font-weight: bold;
  }

  .badge {
    background: rgba(88, 166, 255, 0.1);
    border: 1px solid rgba(88, 166, 255, 0.3);
    border-radius: 6px;
    color: #58a6ff;
    font-weight: 500;
    padding: 4px 8px;
  }

  .badge.text-danger {
    color: #f85149 !important;
    border-color: rgba(248, 81, 73, 0.4);
    background: rgba(248, 81, 73, 0.1);
  }

  .badge.text-warning {
    color: #d29922 !important;
    border-color: rgba(210, 153, 34, 0.4);
    background: rgba(210, 153, 34, 0.1);
  }

  .badge.text-success {
    color: #3fb950 !important;
    border-color: rgba(63, 185, 80, 0.4);
    background: rgba(63, 185, 80, 0.1);
  }

  .badge.text-info {
    color: #58a6ff !important;
    border-color: rgba(88, 166, 255, 0.4);
    background: rgba(88, 166, 255, 0.1);
  }

  .table-bordered td, 
  .table-bordered th {
      border: 1px solid #ffffff !important;
  }

  .table td, 
  .table th {
      border-color: #ffffff !important;
      color: #ffffff;
  }

  .table td:nth-child(3) {
      color: #58a6ff !important;
      font-weight: 600;
  }


  div.dataTables_wrapper div.dataTables_filter input {
      background: rgba(255,255,255,0.05);
      border: 1px solid #0ff;
      color: #0ff;
      border-radius: 8px;
      padding: 6px 12px;
      outline: none;
      transition: 0.3s;
  }
  div.dataTables_wrapper div.dataTables_filter input:focus {
      box-shadow: 0 0 10px #0ff;
      background: rgba(0,255,255,0.1);
  }
  div.dataTables_wrapper div.dataTables_filter label {
      color: #0ff;
      font-weight: bold;
      margin-right: 8px;
  }

  div.dataTables_wrapper div.dataTables_length select {
      background: rgba(255,255,255,0.05);
      border: 1px solid #0ff;
      color: #0ff;
      border-radius: 8px;
      padding: 4px 8px;
      outline: none;
      transition: 0.3s;
  }
  div.dataTables_wrapper div.dataTables_length select:focus {
      box-shadow: 0 0 10px #0ff;
      background: rgba(0,255,255,0.1);
  }
  div.dataTables_wrapper div.dataTables_length label {
      color: #0ff;
      font-weight: bold;
      margin-right: 8px;
  }
</style>


<div id="particles-js"></div>
<div class="row">
    <div class="col-lg-12">
        <div class="alert alert-primary shadow-sm glow-box" role="alert">
            <i class="bi bi-people"></i> Manage System Users
        </div>

        <div class="card shadow-lg border-0 rounded-3 neon-border">
            <div class="card-header bg-dark text-white h6 p-3 d-flex justify-content-between align-items-center">
                <span><i class="bi bi-table"></i> Users Table</span>
                <div class="dropdown">
                    <a class="btn btn-primary dropdown-toggle fw-bold shadow-sm neon-btn" href="#" 
                       role="button" id="navbarDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-file-arrow-down-fill"></i> Open Menu
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end animate__animated animate__fadeInDown" aria-labelledby="navbarDropdown">
                        <li>
                            <a class="dropdown-item" href="<?= site_url('admin/manage-users') ?>">
                                <i class="bi bi-people text-info"></i> Manage Users
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="<?= site_url('keys/generate') ?>">
                                <i class="bi bi-shield-x text-warning"></i> Generate Keys
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="<?= site_url('admin/user/alter') ?>">
                                <i class="bi bi-trash-fill text-danger"></i> Delete Users
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table id="datatable" class="table table-bordered table-hover text-center align-middle" style="width:100%">
                        <thead class="table-dark">
                            <tr>
                                <th scope="row">#</th>
                                <th>Username</th>
                                <th>Fullname</th>
                                <th>Level</th>
                                <th>Saldo</th>
                                <th>Status</th>
                                <th>Uplink</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>


<?= $this->section('css') ?>
<?= link_tag("https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css") ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
<style>
.glow-box {
    text-shadow: 0 0 6px #0ff, 0 0 12px #0ff;
    border-radius: 8px;
}
.neon-border {
    border: 1px solid #0ff;
    box-shadow: 0 0 8px #0ff, 0 0 20px rgba(0,255,255,0.5);
}
.neon-btn {
    border-radius: 8px;
    transition: 0.3s;
}
.neon-btn:hover {
    background: #0ff;
    color: #000 !important;
    box-shadow: 0 0 15px #0ff, 0 0 25px #0ff;
}
.dropdown-menu {
    background: #1e222a;
    border: 1px solid #0ff;
    border-radius: 10px;
    box-shadow: 0 0 15px rgba(0,255,255,0.2);
}
.dropdown-item {
    color: #ddd;
    transition: all 0.3s;
}
.dropdown-item:hover {
    background: rgba(0,255,255,0.2);
    color: #0ff !important;
    font-weight: 500;
}
.table th {
    font-weight: bold;
}
.table td, .table th {
    vertical-align: middle;
}
</style>
<?= $this->endSection() ?>


<?= $this->section('js') ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js") ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js") ?>
<script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
<script>
  particlesJS("particles-js", {
    "particles": {
      "number": { "value": 100, "density": { "enable": true, "value_area": 800 } },
      "color": { "value": "#58a6ff" },
      "shape": { "type": "circle" },
      "opacity": { "value": 0.5 },
      "size": { "value": 3, "random": true },
      "line_linked": {
        "enable": true,
        "distance": 150,
        "color": "#58a6ff",
        "opacity": 0.4,
        "width": 1
      },
      "move": { "enable": true, "speed": 2, "direction": "none", "out_mode": "out" }
    },
    "interactivity": {
      "events": {
        "onhover": { "enable": true, "mode": "grab" },
        "onclick": { "enable": true, "mode": "push" }
      },
      "modes": {
        "grab": { "distance": 140, "line_linked": { "opacity": 1 } },
        "push": { "particles_nb": 4 }
      }
    },
    "retina_detect": true
  });
</script>

<script>
  $(document).ready(function() {
      var table = $('#datatable').DataTable({
          processing: true,
          serverSide: true,
          order: [[0, "desc"]],
          ajax: "<?= site_url('admin/api/users') ?>",
          columns: [
              { data: 'id' },
              { data: 'username' },
              { 
                  data: 'fullname',
                  render: function(data, type, row) {
                      return row.fullname ? row.fullname : '~';
                  }
              },
              { data: 'level' },
              { 
                  data: 'saldo',
                  render: function(data, type, row) {
                      return `<span class="badge text-info">${row.saldo}</span>`;
                  }
              },
              { 
                  data: 'status',
                  render: function(data, type, row) {
                      return row.status == 1 
                          ? `<span class="text-success fw-bold">Active</span>` 
                          : `<span class="text-danger fw-bold">Banned</span>`;
                  }
              },
              { data: 'uplink' },
              { 
                  data: null,
                  render: function(data, type, row) {
                      return `
                          <a href="<?= site_url('admin/user') ?>/${row.id}" class="btn btn-sm btn-primary">EDIT</a>
                          <a href="<?= site_url('admin/user/singledelete') ?>/${row.id}" class="btn btn-sm btn-danger">DELETE</a>
                      `;
                  }
              }
          ]
      });
  });
</script>
<?= $this->endSection() ?>