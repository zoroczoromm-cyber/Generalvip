<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<style>
  body {
    margin:0;
    font-family: 'Poppins', sans-serif;
    background: #0d1117;
    color: #fff;
  }

  #particles-js {
    position: fixed;
    top:0; left:0; width:100%; height:100%;
    z-index: -1;
    background: radial-gradient(circle at top, #0d1117, #05070a);
  }

  .content {
    position: relative;
    z-index: 1;
    padding: 2rem;
  }

  
  .card {
    background: rgba(20, 25, 34, 0.85);
    border: 1px solid rgba(0, 255, 255, 0.2);
    border-radius: 15px;
    box-shadow: 0 0 20px rgba(0,255,255,0.2);
    transition: transform 0.3s ease;
    color: #fff;
  }
  .card:hover {
    transform: translateY(-5px);
    box-shadow: 0 0 25px rgba(0,255,255,0.4);
  }

  .card-header {
    background: linear-gradient(90deg, #0ff2, #0ff4);
    color: #0ff;
    font-weight: 700;
    letter-spacing: 1px;
    border-bottom: 1px solid rgba(0,255,255,0.4);
  }

 
  .form-control, .form-select {
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(0,255,255,0.3);
    color: #fff;
    border-radius: 10px;
    padding: 10px 15px;
    transition: 0.3s;
  }
  .form-control:focus, .form-select:focus {
    border-color: #0ff;
    box-shadow: 0 0 10px #0ff;
    background: rgba(0,255,255,0.1);
  }

 
  .btn {
    border-radius: 10px;
    font-weight: bold;
    transition: all 0.3s ease;
  }
  .btn-outline-dark {
    border: 1px solid #0ff;
    color: #0ff;
  }
  .btn-outline-dark:hover {
    background: #0ff;
    color: #000 !important;
    box-shadow: 0 0 15px #0ff, 0 0 25px #0ff;
  }

  
  .table-bordered td, .table-bordered th {
    border: 1px solid #0ff !important;
  }
  .table td, .table th {
    border-color: #0ff !important;
    color: #fff;
  }
  .table th {
    background: rgba(0,255,255,0.15);
    color: #0ff;
    font-weight: 600;
    text-transform: uppercase;
  }
  .table td:nth-child(3) {
    color: #0ff !important;
    font-weight: 600;
  }
  .table tbody tr:hover {
    background: rgba(0,255,255,0.05);
    box-shadow: inset 0 0 10px rgba(0,255,255,0.2);
  }

 
  .badge {
    border-radius: 6px;
    padding: 4px 8px;
    font-weight: 600;
    background: rgba(0,255,255,0.15);
    color: #0ff;
    border: 1px solid rgba(0,255,255,0.3);
  }
  .badge.text-danger { color:#f85149; border-color:#f85149; background:rgba(248,81,73,0.15);}
  .badge.text-success { color:#3fb950; border-color:#3fb950; background:rgba(63,185,80,0.15);}
</style>



<div id="particles-js"></div>
<div class="row justify-content-center pt-3">
    <div class="col-lg-8 mb-3">
        <div class="card mb-5">
            <div class="card-header p-3 h5">
                Edit Account &middot; <?= getName($target) ?>
            </div>
            <div class="card-body">
                <?= form_open() ?>
                <input type="hidden" name="user_id" value="<?= $target->id_users ?>">
                <div class="row">
                    <div class="col-md-6 mb-2">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" name="username" id="username" class="form-control" value="<?= old('username') ?: $target->username ?>">
                        <?php if ($validation->hasError('username')) : ?>
                            <small class="text-danger"><?= $validation->getError('username') ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6 mb-2">
                        <label for="fullname" class="form-label">Fullname</label>
                        <input type="text" name="fullname" id="fullname" class="form-control" value="<?= old('fullname') ?: $target->fullname ?>">
                        <?php if ($validation->hasError('fullname')) : ?>
                            <small class="text-danger"><?= $validation->getError('fullname') ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6 mb-2">
                        <label for="level" class="form-label">Roles</label>
                        <?php $sel_level = ['' => '&mdash; Select Roles &mdash;', '1' => 'Admin', '2' => 'Reseller']; ?>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'level', 'id' => 'level'], $sel_level, $target->level) ?>
                    </div>
                    <div class="col-md-6 mb-2">
                        <label for="status" class="form-label">Status</label>
                        <?php $sel_status = ['' => '&mdash; Select Status &mdash;', '0' => 'Banned/Block', '1' => 'Active']; ?>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'status', 'id' => 'status'], $sel_status, $target->status) ?>
                    </div>
                    <div class="col-md-6 mb-2">
                        <label for="saldo" class="form-label">Saldo</label>
                        <input type="number" name="saldo" id="saldo" class="form-control" value="<?= old('saldo') ?: $target->saldo ?>">
                        <?php if ($validation->hasError('saldo')) : ?>
                            <small class="text-danger"><?= $validation->getError('saldo') ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6 mb-2">
                        <label for="uplink" class="form-label">Uplink</label>
                        <input type="text" name="uplink" id="uplink" class="form-control" value="<?= old('uplink') ?: $target->uplink ?>">
                        <?php if ($validation->hasError('uplink')) : ?>
                            <small class="text-danger"><?= $validation->getError('uplink') ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-12 mt-2">
                        <button type="submit" class="btn btn-outline-dark w-100">Update Account Information</button>
                    </div>
                </div>
                <?= form_close() ?>
            </div>
        </div>

        <p class="text-muted text-center">
            <a href="<?= site_url('admin/manage-users') ?>" class="py-1 px-2 bg-dark text-light rounded">← Back to Manage users</a>
        </p>
    </div>
</div>
<?= $this->endSection() ?>


<?= $this->section('js') ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js") ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js") ?>
<script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
<script>
  particlesJS("particles-js", {
    "particles": {
      "number": { "value": 100, "density": { "enable": true, "value_area": 800 } },
      "color": { "value": "#0ff" },
      "shape": { "type": "circle" },
      "opacity": { "value": 0.5 },
      "size": { "value": 3, "random": true },
      "line_linked": {
        "enable": true,
        "distance": 150,
        "color": "#0ff",
        "opacity": 0.4,
        "width": 1
      },
      "move": { "enable": true, "speed": 2 }
    },
    "interactivity": {
      "events": { "onhover": { "enable": true, "mode": "grab" } },
      "modes": { "grab": { "distance": 140, "line_linked": { "opacity": 1 } } }
    },
    "retina_detect": true
  });
</script>
<?= $this->endSection() ?>