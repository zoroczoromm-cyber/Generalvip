<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<style>
  html,body { height:100%; margin:0; }
  #particles-js {
    position: fixed;
    top:0; left:0; right:0; bottom:0;
    width:100%; height:100%;
    background-color:#0d1117;
    z-index: -1;
  }



  .modern-card {
    --card-bg: rgba(22,27,34,0.55);
    --card-border: rgba(255,255,255,0.06);
    background: linear-gradient(180deg, rgba(255,255,255,0.02), rgba(0,0,0,0.12));
    backdrop-filter: blur(8px) saturate(120%);
    border-radius: 14px;
    border: 1px solid var(--card-border);
    padding: 16px;
    color: #e6eef8
    box-shadow: 0 6px 18px rgba(2,6,23,0.6);
    margin-bottom: 1rem;
  }

  .stats-card-header, .card-header-unified {
    display:flex; justify-content:space-between; align-items:center; padding:6px 4px;
  }
  .stats-title { display:flex; gap:12px; align-items:center; }
  .stats-icon { width:44px; height:44px; fill: none; background: linear-gradient(135deg,#6dd3ff,#7b61ff); border-radius:10px; padding:7px; }
  .small-label { font-size:12px; color:#9fb3d9; font-weight:600; letter-spacing:0.8px; }
  .stats-title h3 { margin:0; font-weight:800; font-size:18px; color:#dff1ff; }

  .btn-ghost { background:transparent; border:1px solid rgba(255,255,255,0.06); color:#b6d0ff; padding:6px 10px; border-radius:8px; cursor:pointer; font-weight:700; }
  .btn-ghost:hover { transform:translateY(-2px); box-shadow:0 6px 16px rgba(10,20,40,0.4); }

  .stats-grid { display:grid; grid-template-columns: repeat(2,1fr); gap:12px; margin-top:12px; }
  .stat { background: linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01)); padding:12px; border-radius:10px; border:1px solid rgba(255,255,255,0.03); min-height:72px; display:flex; align-items:center; justify-content:space-between; }
  .stat-name { font-size:13px; color:#9fb3d9; font-weight:600; margin:0; }
  .stat-left { display:flex; flex-direction:column; gap:6px; }
  .stat-value { font-weight:800; font-size:20px; color:#e7f6ff; text-align:right; background: rgba(255,255,255,0.02); padding:10px 12px; border-radius:8px; min-width:54px; display:inline-block; }
  .stat-value.big { font-size:26px; padding:12px 16px; background: linear-gradient(90deg, rgba(123,97,255,0.12), rgba(109,211,255,0.06)); }

  .stats-footer { margin-top:10px; display:flex; justify-content:flex-start; align-items:center; color:#9fb3d9; font-size:12px; }

  .info-grid { display:grid; grid-template-columns: 1fr; gap:12px; margin-top:12px; }
  .info-item { background: linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01)); padding:14px; border-radius:10px; border:1px solid rgba(255,255,255,0.03); display:flex; gap:12px; align-items:center; }
  .info-icon { width:36px; height:36px; display:flex; align-items:center; justify-content:center; background: rgba(88,166,255,0.06); border-radius:8px; }
  .info-label { font-size:14px; color:#9fb3d9; }
  .info-value { margin-left:auto; font-weight:700; color:#dff1ff; }

  .visitor-row { display:flex; align-items:center; justify-content:space-between; padding:12px 6px; }
  .counter-badge { background: rgba(58,98,142,0.12); border:1px solid rgba(88,166,255,0.2); padding:10px 14px; border-radius:10px; font-size:24px; font-weight:800; color:#58a6ff; min-width:64px; text-align:center; }

  @media (max-width:768px) {
    .stats-grid { grid-template-columns: 1fr 1fr; }
    .stats-icon { width:44px; height:44px; display:block; }
    .modern-card { padding:14px; }
  }

  .logged-ip-card {
    display:flex; gap:16px; align-items:center; background:#161b22; border:1px solid #58a6ff; box-shadow:0 1px 3px rgba(0,0,0,0.3); padding:12px; border-radius:12px; max-width:420px; margin: 12px 0;
  }
  .logged-ip-icon { width:48px; height:48px; display:flex; align-items:center; justify-content:center; background:#3b82f6; border-radius:10px; }
  .logged-ip-icon svg { width:26px; height:26px; fill:white; }
  .logged-ip-title { font-weight:600; font-size:16px; color:#fff; margin:0; }
</style>

<div id="particles-js"></div>
<?= $this->include('Layout/msgStatus') ?>

<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="./v.css">
</head>
<body>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>EL3FrT</title>

<div class="content">

  <div class="logged-ip-card">
    <div class="logged-ip-icon">
      <svg viewBox="0 0 24 24"><path d="M12 2l7 3v5c0 5-3.8 9.5-7 11-3.2-1.5-7-6-7-11V5l7-3z"/></svg>
    </div>
    <div>
      <p class="logged-ip-title" id="user-ip-text"><?php echo isset($ip) ? $ip : ''; ?></p>
    </div>
  </div>

  <div class="modern-card" id="card-stats-1">
    <div class="stats-card-header">
      <div class="stats-title">
        <div>
          <div class="small-label">Overview</div>
          <h3>Users &amp; Keys</h3>
        </div>
      </div>
      <div class="stats-actions">
        <button class="btn-ghost" onclick="refreshStats('stats-updated-1')" title="Refresh">⟳</button>
      </div>
    </div>

    <div class="stats-grid">
      <div class="stat">
        <div class="stat-left">
          <div class="stat-name">Total Keys</div>
        </div>
        <div class="stat-value countup" data-value="<?= $keysAll ?>">0</div>
      </div>

      <div class="stat">
        <div class="stat-left">
          <div class="stat-name">Sold Keys</div>
        </div>
        <div class="stat-value countup" data-value="<?= $usedKeys ?>">0</div>
      </div>

      <div class="stat">
        <div class="stat-left">
          <div class="stat-name">Unused Keys</div>
        </div>
        <div class="stat-value countup" data-value="<?= $unusedKeys ?>">0</div>
      </div>

      <div class="stat">
        <div class="stat-left">
          <div class="stat-name">Total Users</div>
        </div>
        <div class="stat-value big countup" data-value="<?= $userAll ?>">0</div>
      </div>
    </div>

    <div class="stats-footer">
      <small class="muted">Updated: <span id="stats-updated-1">Just now</span></small>
    </div>
  </div>

  <div class="modern-card" id="card-info-2">
    <div class="card-header-unified">
      <div class="stats-title">
        <div>
          <div class="small-label">Information</div>
          <h3>Account Info</h3>
        </div>
      </div>
      <div class="stats-actions">
        <button class="btn-ghost" onclick="refreshStats('stats-updated-2')" title="Refresh">⟳</button>
      </div>
    </div>

    <div class="info-grid">
      <div class="info-item">
        <div class="info-icon">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 12c2.21 0 4-1.79 4-4S14.21 4 12 4 8 5.79 8 8s1.79 4 4 4zM12 14c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
        </div>
        <div>
          <div class="info-label">Role</div>
        </div>
        <div class="info-value">
                            <?= getLevel($user->level) ?></div>
      </div>

      <div class="info-item">
        <div class="info-icon">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 1C5.93 1 1 5.93 1 12s4.93 11 11 11 11-4.93 11-11S18.07 1 12 1zM6 12h6v2H6v-2zm0-4h12v2H6V8z"/></svg>
        </div>
        <div>
          <div class="info-label">Dollar</div>
        </div>
        <div class="info-value">
                            $<?= $user->saldo ?></div>
      </div>

      <div class="info-item">
        <div class="info-icon">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 8V4l8 8-8 8v-4H4V8h8z"/></svg>
        </div>
        <div>
          <div class="info-label">Login Time</div>
        </div>
        <div class="info-value"><?= $time::parse(session()->time_since)->humanize() ?></div>
      </div>

      <div class="info-item">
        <div class="info-icon">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M10 17l5-5-5-5v10zM5 19h2V5H5v14z"/></svg>
        </div>
        <div>
          <div class="info-label">Auto Logout</div>
        </div>
        <div class="info-value"><?= $time::now()->difference($time::parse(session()->time_login))->humanize() ?></div>
      </div>
    </div>

    <div class="stats-footer">
      <small class="muted">Updated: <span id="stats-updated-2">Just now</span></small>
    </div>
  </div>

  <div class="modern-card" id="card-visitor-3">
    <div class="card-header-unified">
      <div class="stats-title">
        <div>
          <div class="small-label">Visitors</div>
          <h3>Your Visitor Count is</h3>
        </div>
      </div>
      <div class="stats-actions">
        <button class="btn-ghost" onclick="refreshStats('stats-updated-3')" title="Refresh">⟳</button>
      </div>
    </div>

      <div class="info-item">
        <div class="info-icon">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 5c-7 0-11 7-11 7s4 7 11 7 11-7 11-7-4-7-11-7zm0 12a5 5 0 1 1 0-10 5 5 0 0 1 0 10zm0-8a3 3 0 1 0 0 6 3 3 0 0 0 0-6z"/></svg>
        </div>
        <div>
          <div class="info-label">Counter no is</div>
        </div>
        <div class="info-value"><h5 id="CounterVisitor">0</h5></div>
      </div>

    <div class="stats-footer">
      <small class="muted">Updated: <span id="stats-updated-3">Just now</span></small>
    </div>
  </div>

</div> 

<!-- scripts (kept and adjusted to support multiple cards) -->
<script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
<script>
  particlesJS("particles-js", {
    "particles": {
      "number": { "value": 100, "density": { "enable": true, "value_area": 800 } },
      "color": { "value": "#58a6ff" },
      "shape": { "type": "circle" },
      "opacity": { "value": 0.5 },
      "size": { "value": 3, "random": true },
      "line_linked": {
        "enable": true,
        "distance": 150,
        "color": "#58a6ff",
        "opacity": 0.4,
        "width": 1
      },
      "move": {
        "enable": true,
        "speed": 2,
        "direction": "none",
        "out_mode": "out"
      }
    },
    "interactivity": {
      "events": {
        "onhover": { "enable": true, "mode": "grab" },
        "onclick": { "enable": true, "mode": "push" }
      },
      "modes": {
        "grab": { "distance": 140, "line_linked": { "opacity": 1 } },
        "push": { "particles_nb": 4 }
      }
    },
    "retina_detect": true
  });
</script>

<script>
  if (typeof $ !== 'undefined' && $.getJSON) {
    $.getJSON("https://api.ipify.org?format=json", function(data) {
      $("#user-ip-text").html(data.ip);
    });
  } else {
    // fallback: try fetch
    fetch("https://api.ipify.org?format=json").then(r => r.json()).then(data => {
      var el = document.getElementById('user-ip-text');
      if(el) el.innerText = data.ip;
    }).catch(()=>{});
  }
</script>

<script>
  // simple visitor counter using localStorage (kept original behavior)
  (function(){
    var n = localStorage.getItem('on_load_counter');
    if (n === null) { n = 0; }
    n++;
    localStorage.setItem("on_load_counter", n);
    var nums = n.toString().split('').map(Number);
    var el = document.getElementById('CounterVisitor');
    if(el){
      el.innerHTML = '';
      for (var i of nums) {
        el.innerHTML += '<span class="counter-item">' + i + '</span>';
      }
    }
  })();
</script>

<script>
  function animateCountUp(el){
    const target = parseInt(el.getAttribute('data-value')) || 0;
    let count = 0;
    const step = Math.max(1, Math.ceil(target/40));
    const interval = setInterval(()=>{
      count += step;
      if(count >= target){
        count = target;
        clearInterval(interval);
      }
      el.innerText = count;
    }, 20);
  }

  function startAllCountUps(){
    document.querySelectorAll('.countup').forEach(el=>{
      el.innerText='0';
      animateCountUp(el);
    });
  }

  function refreshStats(updatedId){
    const btn = event?.currentTarget;
    if(btn) btn.disabled=true;
    if(updatedId){
      var upEl = document.getElementById(updatedId);
      if(upEl) upEl.innerText = 'Refreshing...';
    }
    setTimeout(()=> {
      var now = new Date().toLocaleTimeString();
      if(updatedId){
        var upEl2 = document.getElementById(updatedId);
        if(upEl2) upEl2.innerText = now;
      } else {
        ['stats-updated-1','stats-updated-2','stats-updated-3'].forEach(id=>{
          var x = document.getElementById(id);
          if(x) x.innerText = now;
        });
      }
      startAllCountUps();
      if(btn) btn.disabled=false;
    },700);
  }

  window.addEventListener('load', startAllCountUps);
</script>

</body>
<?= $this->endSection() ?>