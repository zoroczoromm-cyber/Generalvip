<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<style>
  html,body { height:100%; margin:0; }
  #particles-js {
    position: fixed;
    top:0; left:0; right:0; bottom:0;
    width:100%; height:100%;
    background-color:#0d1117; 
    z-index: -1;
  }
  /* الحقول */
.form-control, 
.form-select {
  background: rgba(13, 17, 23, 0.8) !important; /* غامق */
  color: #e6edf3 !important; /* نص فاتح */
  border: 1px solid #58a6ff !important; /* أزرق */
  border-radius: 8px;
}

.form-control:focus, 
.form-select:focus {
  background: rgba(13, 17, 23, 0.95) !important;
  border-color: #0ff !important;
  box-shadow: 0 0 8px #0ff !important;
  color: #fff !important;
}
.card { background:rgba(22,27,34,0.85); border:1px solid rgba(88,166,255,0.3); border-radius:12px; color:#e6edf3; }
.card-header { background:rgba(88,166,255,0.1); border-bottom:1px solid rgba(88,166,255,0.3); color:#58a6ff; font-weight:bold; text-shadow:0 0 6px #58a6ff; }
table.table { color:#e6edf3 !important; }
table.table thead th { background:rgba(88,166,255,0.12) !important; color:#58a6ff !important; text-shadow:0 0 6px #58a6ff; }
table.table tbody tr:nth-child(even) { background:rgba(88,166,255,0.05) !important; }
table.table tbody tr:nth-child(odd) { background:rgba(22,27,34,0.6) !important; }
table.table tbody tr:hover { background:rgba(88,166,255,0.15) !important; }

/* widgets grid */
.dashboard-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:14px; margin-bottom:20px; }
.widget { background:rgba(22,27,34,0.88); border:1px solid rgba(88,166,255,0.25); border-radius:12px; padding:16px; text-align:center; box-shadow:0 0 14px rgba(0,0,0,0.3); }
.widget svg { width:32px; height:32px; margin-bottom:6px; fill:#58a6ff; }
.widget .title { color:#58a6ff; font-weight:600; font-size:14px; margin-bottom:4px; }
.widget .val { font-size:1.2rem; font-weight:700; color:#fff; }
</style>



<div id="particles-js"></div>

<div class="row pb-5 justify-content-center">
    <div class="col-lg-8 mb-3">
        <div class="card border-0 shadow-sm">
            <div class="card-header py-3">
                <div class="row align-items-center">
                    <div class="col pt-1">
                        <h5 class="mb-0"><i class="bi bi-pencil-square me-2"></i>تعديل معلومات المشترك</h5>
                    </div>
                    <div class="col-auto">
                        <div class="btn-group">
                            <a class="btn btn-sm btn-light" href="<?= site_url('keys/generate') ?>">
                                <i class="bi bi-person-plus me-1"></i> جديد
                            </a>
                            <a class="btn btn-sm btn-outline-light" href="<?= site_url('public/keys') ?>">
                                <i class="bi bi-people me-1"></i> المشتركين
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?= form_open('/keys/edit') ?>

                <div class="row g-3">
                    <input type="hidden" name="id_keys" value="<?= $key->id_keys ?>">
                    <?php if ($user->level == 1) : ?>
                        <div class="col-lg-6 mb-3">
                            <label for="game" class="form-label fw-bold text-primary">اللعبة</label>
                            <input type="text" name="game" id="game" class="form-control border-primary border-2" value="<?= old('game') ?: $key->game ?>">
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label for="user_key" class="form-label fw-bold text-primary">المفتاح</label>
                            <input type="text" name="user_key" id="user_key" class="form-control border-primary border-2" value="<?= old('user_key') ?: $key->user_key ?>">
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label for="duration" class="form-label fw-bold text-primary">عدد الأيام</label>
                            <input type="number" name="duration" id="duration" class="form-control border-primary border-2" value="<?= old('duration') ?: $key->duration ?>">
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label for="max_devices" class="form-label fw-bold text-primary">عدد الأجهزة</label>
                            <input type="number" name="max_devices" id="max_devices" class="form-control border-primary border-2" value="<?= old('max_devices') ?: $key->max_devices ?>">
                        </div>
                    <?php endif; ?>
                    <div class="col-md-6 mb-3">
                        <label for="status" class="form-label fw-bold text-primary">حالة المفتاح</label>
                        <?php $sel_status = ['' => '&mdash; اختر الحالة &mdash;', '0' => 'محظور', '1' => 'مفعل']; ?>
                        <?= form_dropdown(['class' => 'form-select border-primary border-2', 'name' => 'status', 'id' => 'status'], $sel_status, $key->status) ?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="registrator" class="form-label fw-bold text-primary">المالك</label>
                        <input type="text" name="registrator" id="registrator" class="form-control border-primary border-2" value="<?= old('registrator') ?: $key->registrator ?>">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="expired_date" class="form-label fw-bold text-primary">تاريخ الانتهاء</label>
                        <input type="text" name="expired_date" id="expired_date" class="form-control border-primary border-2" value="<?= old('expired_date') ?: $key->expired_date ?>">
                    </div>
                    <div class="col-lg-12 mb-4">
                        <label for="devices" class="form-label fw-bold text-primary">الأجهزة 
                          <span class="badge bg-gradient-primary rounded-pill maxDev"><?= $key_info->total ?>/<?= $key->max_devices ?></span>
                        </label>
                        <textarea class="form-control border-primary border-2" name="devices" id="devices" style="min-height: 100px;"><?= old('devices') ?: ($key_info->total ? $key_info->devices : '') ?></textarea>
                    </div>
                    <div class="col-lg-12">
              <button type="submit" class="btn btn-outline-info w-100">
                            <i class="bi bi-plus-circle"></i> تحديث المعلومات
                        </button>
                    </div>
                    <?= form_close() ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script>
    $(document).ready(function() {
        var level = "<?= $user->level ?>";
        if (level != 1) $("#registrator, #expired_date, #devices").attr('disabled', true);
        $("input, select, textarea").change(function() {
            $(".btnUpdate").attr('disabled', false).removeClass('btn-primary').addClass('btn-success');
        });
    });
    var total = "<?= $key_info->total ?>";
    $("#max_devices").change(function() {
        $(".maxDev").html(total + '/' + $(this).val());
        $("#devices").attr('rows', $(this).val());
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
<script>
  particlesJS("particles-js", {
    "particles": {
      "number": { "value": 100, "density": { "enable": true, "value_area": 800 } },
      "color": { "value": "#0ff" },
      "shape": { "type": "circle" },
      "opacity": { "value": 0.5 },
      "size": { "value": 3, "random": true },
      "line_linked": { "enable": true, "distance": 150, "color": "#0ff", "opacity": 0.4, "width": 1 },
      "move": { "enable": true, "speed": 2, "direction": "none", "out_mode": "out" }
    },
    "interactivity": {
      "events": { "onhover": { "enable": true, "mode": "grab" }, "onclick": { "enable": true, "mode": "push" } },
      "modes": { "grab": { "distance": 140, "line_linked": { "opacity": 1 } }, "push": { "particles_nb": 4 } }
    },
    "retina_detect": true
  });
</script>
<?= $this->endSection() ?>