<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<style>
  html, body { 
    height:100%; margin:0; 
    font-family: 'Segoe UI', sans-serif;
    color:#fff;
  }
  #particles-js {
    position: fixed;
    inset:0;
    width:100%; height:100%;
    background:#0d1117;
    z-index:-1;
  }

  .dashboard {
    position: relative;
    z-index: 1;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: 2rem;
  }

  .grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr); /* دائرتين بالصف */
    gap: 2rem;
    width: 100%;
    max-width: 600px; /* عرض أصغر حتى تكون مرتبة */
  }

  .circle-card {
    background: rgba(255,255,255,0.06);
    border: 1px solid rgba(88,166,255,0.25);
    border-radius: 50%;
    width: 140px;
    height: 140px;
    margin: auto;
    backdrop-filter: blur(12px);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    transition: transform .3s ease, box-shadow .3s ease;
  }
  .circle-card:hover {
    transform: scale(1.08);
    box-shadow: 0 0 20px rgba(88,166,255,0.4);
  }

  .circle-card svg {
    width: 28px;
    height: 28px;
    margin-bottom: 6px;
    fill: #58a6ff;
  }
  .circle-card .value {
    font-size: 1.1rem;
    font-weight: bold;
  }
  .circle-card .label {
    font-size: 0.8rem;
    opacity: 0.8;
  }
  html,body { height:100%; margin:0; }
  #particles-js {
    position: fixed;
    top:0; left:0; right:0; bottom:0;
    width:100%; height:100%;
    background-color:#0d1117; 
    z-index: -1;
  }
  
.card { background:rgba(22,27,34,0.85); border:1px solid rgba(88,166,255,0.3); border-radius:12px; color:#e6edf3; }
.card-header { background:rgba(88,166,255,0.1); border-bottom:1px solid rgba(88,166,255,0.3); color:#58a6ff; font-weight:bold; text-shadow:0 0 6px #58a6ff; }
table.table { color:#e6edf3 !important; }
table.table thead th { background:rgba(88,166,255,0.12) !important; color:#58a6ff !important; text-shadow:0 0 6px #58a6ff; }
table.table tbody tr:nth-child(even) { background:rgba(88,166,255,0.05) !important; }
table.table tbody tr:nth-child(odd) { background:rgba(22,27,34,0.6) !important; }
table.table tbody tr:hover { background:rgba(88,166,255,0.15) !important; }

/* widgets grid */
.dashboard-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:14px; margin-bottom:20px; }
.widget { background:rgba(22,27,34,0.88); border:1px solid rgba(88,166,255,0.25); border-radius:12px; padding:16px; text-align:center; box-shadow:0 0 14px rgba(0,0,0,0.3); }
.widget svg { width:32px; height:32px; margin-bottom:6px; fill:#58a6ff; }
.widget .title { color:#58a6ff; font-weight:600; font-size:14px; margin-bottom:4px; }
.widget .val { font-size:1.2rem; font-weight:700; color:#fff; }
  .content {
    position: relative;
    z-index: 1;
    padding: 2rem;
  }

  
  .card {
    background: rgba(20, 25, 34, 0.85);
    border: 1px solid rgba(0, 255, 255, 0.2);
    border-radius: 15px;
    box-shadow: 0 0 20px rgba(0,255,255,0.2);
    transition: transform 0.3s ease;
    color: #fff;
  }
  .card:hover {
    transform: translateY(-5px);
    box-shadow: 0 0 25px rgba(0,255,255,0.4);
  }

  .card-header {
    background: linear-gradient(90deg, #0ff2, #0ff4);
    color: #0ff;
    font-weight: 700;
    letter-spacing: 1px;
    border-bottom: 1px solid rgba(0,255,255,0.4);
  }

 
  .form-control, .form-select {
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(0,255,255,0.3);
    color: #fff;
    border-radius: 10px;
    padding: 10px 15px;
    transition: 0.3s;
  }
  .form-control:focus, .form-select:focus {
    border-color: #0ff;
    box-shadow: 0 0 10px #0ff;
    background: rgba(0,255,255,0.1);
  }
/* الهيدر تبع الكارد */
.card-header.bg-primary {
  background: linear-gradient(90deg, #0ff2, #0ff4) !important;
  color: #0ff !important;
  border-bottom: 1px solid rgba(0,255,255,0.4) !important;
  text-shadow: 0 0 6px #0ff;
}

/* الأزرار */
.btn-primary {
  background: #0ff !important;
  border: 1px solid #0ff !important;
  color: #000 !important;
  font-weight: bold;
  transition: 0.3s;
}
.btn-primary:hover {
  background: #00e6e6 !important;
  box-shadow: 0 0 15px #0ff, 0 0 25px #0ff;
  color: #000 !important;
}
 
  .btn {
    border-radius: 10px;
    font-weight: bold;
    transition: all 0.3s ease;
  }
  .btn-outline-dark {
    border: 1px solid #0ff;
    color: #0ff;
  }
  .btn-outline-dark:hover {
    background: #0ff;
    color: #000 !important;
    box-shadow: 0 0 15px #0ff, 0 0 25px #0ff;
  }

  
  .table-bordered td, .table-bordered th {
    border: 1px solid #0ff !important;
  }
  .table td, .table th {
    border-color: #0ff !important;
    color: #fff;
  }
  .table th {
    background: rgba(0,255,255,0.15);
    color: #0ff;
    font-weight: 600;
    text-transform: uppercase;
  }
  .table td:nth-child(3) {
    color: #0ff !important;
    font-weight: 600;
  }
  .table tbody tr:hover {
    background: rgba(0,255,255,0.05);
    box-shadow: inset 0 0 10px rgba(0,255,255,0.2);
  }

 
  .badge {
    border-radius: 6px;
    padding: 4px 8px;
    font-weight: 600;
    background: rgba(0,255,255,0.15);
    color: #0ff;
    border: 1px solid rgba(0,255,255,0.3);
  }
  .badge.text-danger { color:#f85149; border-color:#f85149; background:rgba(248,81,73,0.15);}
  .badge.text-success { color:#3fb950; border-color:#3fb950; background:rgba(63,185,80,0.15);}
</style>


<div id="particles-js"></div>
<br>
<div class="row justify-content-center">
    <div class="col-lg-6">
        

        <div class="card">
            <div class="card-header p-3 text-center text-black">
                <strong>Create License</strong>
            </div>
            <div class="card-body">
                <?= form_open() ?>

                <div class="form-group mb-3">
                    <label for="game" class="form-label">Games</label>
                    <select class="form-select" name="game" id="game">
                        <?php foreach ($game as $key => $value) : ?>
                            <option value="<?= $key ?>"><?= $value ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group mb-3">
                    <label for="max_devices" class="form-label">Max Devices</label>
                    <input type="number" name="max_devices" id="max_devices" class="form-control" placeholder="1" value="<?= old('max_devices') ?: 1 ?>">
                </div>

                <div class="form-group mb-3">
                    <label for="duration" class="form-label">Duration</label>
                    <?= form_dropdown(['class' => 'form-select', 'name' => 'duration', 'id' => 'duration'], $duration, old('duration') ?: '') ?>
                </div>

                <div class="form-group mb-3">
                    <label for="bulk_keys" class="form-label">Bulk Keys</label>
                    <select class="form-select" name="loopcount" id="loopcount">
                        <option value="1">1 Key</option>
                        <option value="5">5 Keys</option>
                        <option value="10">10 Keys</option>
                        <option value="50">50 Keys</option>
                        <option value="100">100 Keys</option>
                    </select>
                </div>

                <div class="form-group text-center mt-3">
                    <button type="submit" class="btn btn-outline-dark">Generate</button>
                </div>

                <?= form_close() ?>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script>
    $(document).ready(function() {
        var price = JSON.parse('<?= $price ?>');
        updatePrice(price);

        $("#max_devices, #duration, #game").change(function() {
            updatePrice(price);
        });

        function updatePrice(price) {
            var device = $("#max_devices").val();
            var duration = $("#duration").val();
            var gamePrice = price[duration];

            if (!isNaN(gamePrice)) {
                var result = device * gamePrice;
                $("#estimation").val(result);
            } else {
                $("#estimation").val('Estimation error');
            }
        }
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
<script>
  particlesJS("particles-js", {
    "particles": {
      "number": { "value": 100, "density": { "enable": true, "value_area": 800 } },
      "color": { "value": "#58a6ff" },
      "shape": { "type": "circle" },
      "opacity": { "value": 0.5 },
      "size": { "value": 3, "random": true },
      "line_linked": { "enable": true, "distance": 150, "color": "#58a6ff", "opacity": 0.4, "width": 1 },
      "move": { "enable": true, "speed": 2, "direction": "none", "out_mode": "out" }
    },
    "interactivity": {
      "events": { "onhover": { "enable": true, "mode": "grab" }, "onclick": { "enable": true, "mode": "push" } },
      "modes": { "grab": { "distance": 140, "line_linked": { "opacity": 1 } }, "push": { "particles_nb": 4 } }
    },
    "retina_detect": true
  });
</script>
<?= $this->endSection() ?>
