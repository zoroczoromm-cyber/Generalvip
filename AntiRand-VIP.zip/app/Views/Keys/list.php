<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<style>

.swal2-popup {
  background: #0d1117 !important;
  border: 1px solid #00ffff !important;
  border-radius: 15px !important;
  color: #c9d1d9 !important;
  box-shadow: 0 0 20px rgba(0,255,255,0.6),
              0 0 40px rgba(0,255,255,0.3) !important;
  animation: neonZoomIn 0.4s ease;
}


.swal2-title {
  color: #0ff !important;
  text-shadow: 0 0 6px #0ff, 0 0 12px #0ff;
  font-weight: bold;
  font-size: 22px !important;
}


.swal2-html-container {
  color: #c9d1d9 !important;
  font-size: 16px;
}

@keyframes neonZoomIn {
  from { transform: scale(0.8); opacity: 0; }
  to { transform: scale(1); opacity: 1; }
}

.btn-sm {
  border-radius: 10px;
  font-size: 14px;
  padding: 6px 10px;
  transition: all 0.3s ease-in-out;
  background: rgba(0,255,255,0.05);
  border: 1px solid rgba(0,255,255,0.5);
  color: #0ff !important;
}

.btn-sm:hover {
  background: #0ff;
  color: #000 !important;
  box-shadow: 0 0 15px #0ff, 0 0 25px #0ff;
  transform: scale(1.1) rotate(-2deg);
}


.btn-sm i {
  font-size: 16px;
  transition: 0.3s;
}

.btn-sm:hover i {
  transform: rotate(15deg) scale(1.2);
}

.dataTables_filter label {
  color: #0ff;
  font-weight: bold;
  text-shadow: 0 0 6px #0ff;
}

.dataTables_filter input {
  background: rgba(22, 27, 34, 0.85);
  border: 1px solid #0ff;
  border-radius: 8px;
  color: #0ff;
  padding: 6px 12px;
  margin-left: 6px;
  outline: none;
  transition: 0.3s;
}

.dataTables_filter input:focus {
  box-shadow: 0 0 12px #0ff, 0 0 20px rgba(0,255,255,0.5);
}

.dataTables_length label {
  color: #0ff;
  font-weight: bold;
  text-shadow: 0 0 6px #0ff;
}

.dataTables_length select {
  background: rgba(22, 27, 34, 0.85);
  border: 1px solid #0ff;
  border-radius: 8px;
  color: #0ff;
  padding: 6px 12px;
  margin: 0 6px;
  outline: none;
  transition: 0.3s;
}

.dataTables_length select:focus {
  box-shadow: 0 0 12px #0ff, 0 0 20px rgba(0,255,255,0.5);
}

/* تموضع Show + Search بنفس السطر */
.dataTables_length,
.dataTables_filter {
  display: inline-block;
  vertical-align: middle;
  margin: 10px;
}

.dataTables_length {
  float: left;
}

.dataTables_filter {
  float: right;
}
.table thead th {
  color: #58a6ff !important;  
  font-weight: bold;
  text-shadow: 0 0 8px #58a6ff;
}

.table tbody td {
  color: #c9d1d9 !important;   
  font-weight: 500;
}
  html,body { height:100%; margin:0; }
  #particles-js {
    position: fixed;
    top:0; left:0; right:0; bottom:0;
    width:100%; height:100%;
    background-color:#0d1117; 
    z-index: -1;
  }

  .content {
    position: relative;
    z-index: 1;
    color: #ffffff;
    font-family: sans-serif;
    padding: 2rem;
  }

  .card {
    background-color: rgba(22, 27, 34, 0.85);
    border: 1px solid rgba(88, 166, 255, 0.2);
    border-radius: 10px;
    backdrop-filter: blur(6px);
    color: #ffffff;
  }

  .card-header {
    background: linear-gradient(90deg, #161b22, #1f2a37);
    border-bottom: 1px solid rgba(88, 166, 255, 0.3);
    font-weight: 600;
    letter-spacing: 0.5px;
    color: #ffffff;
  }

  .card-body,
  .list-group-item {
    background: transparent !important;
    color: #ffffff;
  }

  .bg-primary {
    background: rgba(88, 166, 255, 0.15) !important;
    color: #58a6ff !important;
    font-weight: bold;
  }

  .dropdown-menu {
    background: #1e1e1e;
    border: 1px solid #0ff;
    border-radius: 12px;
    box-shadow: 0 0 15px rgba(0,255,255,0.3);
    padding: 10px;
    min-width: 220px;
  }
  .dropdown-item {
    color: #fff;
    padding: 10px 15px;
    border-radius: 8px;
    margin: 4px 0;
    transition: all 0.3s ease;
    background: rgba(0,255,255,0.05);
    border: 1px solid rgba(0,255,255,0.2);
  }
  .dropdown-item:hover {
    background: rgba(0,255,255,0.3);
    color: #0ff;
    box-shadow: 0 0 10px #0ff;
  }
  .dropdown-header {
    font-weight: bold;
    color: #0ff;
    text-align: center;
    margin-bottom: 5px;
  }
  .badge {
  color: #fff !important;
  } 
</style>



<div id="particles-js"></div>

<div class="row justify-content-center">
    <div class="col-lg-12">
        
    </div>
    <div class="col-lg-12">
        <div class="card shadow-sm">
            <div class="card-header">
                <strong>Keys Registered</strong>
            </div>

            <div class="card-body">
                <?php if ($keylist) : ?>
                    <div class="table-responsive">
                        <table id="datatable" class="table table-bordered text-center" style="width:100%">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Game</th>
                                    <th>User Keys</th>
                                    <th>Devices</th>
                                    <th>Duration</th>
                                    <th>Expired</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                <?php else : ?>
                    <p class="text-center">No keys available</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js") ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js") ?>
<script>
$(document).ready(function() {
    $('#datatable').DataTable({
        processing: true,
        serverSide: true,
        order: [[0, "desc"]],
        ajax: "<?= site_url('keys/api') ?>",
        dom: 'ftr', // f = filter (search), t = table, r = processing
        paging: false,      // يشيل التصفح (pagination)
        info: false,        // يشيل معلومات "Showing 1 to 10 of ..."
        lengthChange: false, // يشيل خيارات 10/25/50
        columns: [
            { data: 'id' },
            { data: 'game' },
            { 
                data: 'user_key',
                render: function(data, type, row) {
                    var is_valid = row.status === 'Active' ? "text-success" : "text-danger";
                    return `<span class="${is_valid}">${row.user_key ? row.user_key : '&mdash;'}</span>`;
                }
            },
            { 
                data: 'devices',
                render: function(data, type, row) {
                    return `<span>${row.devices || 0}/${row.max_devices}</span>`;
                }
            },
            { data: 'duration' },
            { 
                data: 'expired',
                render: function(data, type, row) {
                    return row.expired ? `<span class="badge text-dark">${row.expired}</span>` : '(not started yet)';
                }
            },
            {
                data: null,
                render: function(data, type, row) {
                    return `
                        <button class="btn btn-outline-warning btn-sm" onclick="resetUserKey('${row.user_key}')">
                            <i class="bi bi-bootstrap-reboot"></i>
                        </button>
                        <a href="<?= site_url('keys/') ?>${row.id}" class="btn btn-outline-dark btn-sm">
                            <i class="bi bi-gear"></i>
                        </a>
                        <button class="btn btn-outline-danger btn-sm" onclick="deleteKeys('${row.user_key}')">
                            <i class="bi bi-trash"></i>
                        </button>
                    `;
                }
            }
        ]
    });
});

    function deleteKeys(keys) {
        Swal.fire({
            title: 'Are you sure?',
            text: "You can't undo this action!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d32f2f',
            cancelButtonColor: '#424242',
            confirmButtonText: 'Yes, delete'
        }).then((result) => {
            if (result.isConfirmed) {
                $.getJSON("<?= site_url('keys/delete') ?>", { userkey: keys, delete: 1 }, function(data) {
                    if (data.delete) {
                        Swal.fire('Deleted!', 'Key has been removed.', 'success');
                        location.reload();
                    } else {
                        Swal.fire('Failed!', "You don't have permission.", 'error');
                    }
                });
            }
        });
    }

    function resetUserKey(keys) {
        Swal.fire({
            title: 'Are you sure?',
            text: "This will reset the key!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#ff9800',
            cancelButtonColor: '#424242',
            confirmButtonText: 'Yes, reset'
        }).then((result) => {
            if (result.isConfirmed) {
                $.getJSON("<?= site_url('keys/reset') ?>", { userkey: keys, reset: 1 }, function(data) {
                    if (data.reset) {
                        Swal.fire('Reset!', 'Key has been reset.', 'success');
                    } else {
                        Swal.fire('Failed!', "The key is already reset.", 'warning');
                    }
                });
            }
        });
    }
</script>

<script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
<script>
  particlesJS("particles-js", {
  "particles": {
    "number": { "value": 100, "density": { "enable": true, "value_area": 800 } },
    "color": { "value": "#58a6ff" },
    "shape": { "type": "circle" },
    "opacity": { "value": 0.5 },
    "size": { "value": 3, "random": true },
    "line_linked": { "enable": true, "distance": 150, "color": "#58a6ff", "opacity": 0.4, "width": 1 },
    "move": { "enable": true, "speed": 2, "direction": "none", "out_mode": "out" }
  },
  "interactivity": {
    "events": { "onhover": { "enable": true, "mode": "grab" }, "onclick": { "enable": true, "mode": "push" } },
    "modes": { "grab": { "distance": 140, "line_linked": { "opacity": 1 } }, "push": { "particles_nb": 4 } }
  },
  "retina_detect": true,
  "background": {
    "color": "#0d1117"   // 🔥 هنا يتحكم بلون الخلفية
  }
});
</script>
<?= $this->endSection() ?>
