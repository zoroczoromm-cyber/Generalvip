<header>
      <?php if (session()->has('userid')): ?>
<div class="col-lg-3 position-relative">
  <!-- زر عائم -->
  <div class="fab-wrapper">
    <div class="fab" id="fab">
      <span></span>
    </div>
    <div class="menu" id="menu">

        <?php if (isset($user) && $user->level == 1): ?>
          <!-- Protect Your Lib -->
          <a href="http://www.xmprotect.com/" title="Protect Your Lib">
            <i class="bi bi-file-earmark-lock2-fill"></i>
          </a>
          <!-- Manage Users -->
          <a href="<?= site_url('admin/manage-users') ?>" title="Manage Users">
            <i class="bi bi-people"></i>
          </a>

          <!-- Create Reseller -->
          <a href="<?= site_url('admin/create-referral') ?>" title="Create Reseller">
            <i class="bi bi-person-plus"></i>
          </a>
        <?php endif; ?>
        <!-- Settings -->
        <a href="<?= site_url('settings') ?>" title="Settings">
          <i class="bi bi-gear"></i>
        </a>
        <!-- Logout -->
        <a href="<?= site_url('logout') ?>" title="Logout" class="text-danger">
          <i class="bi bi-box-arrow-in-left"></i>
        </a>
    </div>
  </div>
</div>
      <?php endif; ?>

<style>
  .fab-wrapper {
    position: absolute;
    top: 15px;
    right: 15px;
    z-index: 20;
    display: flex;
    flex-direction: column;
    align-items: flex-end;
  }
  .fab {
    width: 50px;
    height: 50px;
    background: #0ff;
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    box-shadow: 0 0 10px #0ff, 0 0 20px #0ff;
    transition: transform 0.3s ease;
  }
  .fab:hover { transform: scale(1.1); }
  .fab span {
    position: relative;
    width: 20px;
    height: 2px;
    background: #000;
    border-radius: 3px;
    transition: 0.3s;
  }
  .fab span::before,
  .fab span::after {
    content: "";
    position: absolute;
    width: 20px;
    height: 2px;
    background: #000;
    border-radius: 3px;
    left: 0;
    transition: 0.3s;
  }
  .fab span::before { top: -6px; }
  .fab span::after { top: 6px; }
  .fab.active span { background: transparent; }
  .fab.active span::before { transform: rotate(45deg); top: 0; }
  .fab.active span::after { transform: rotate(-45deg); top: 0; }
  .menu {
    margin-top: 12px;
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: flex-end;
    gap: 12px;
    opacity: 0;
    transform: scale(0.8);
    transition: all 0.25s ease;
    pointer-events: none;
    max-width: 260px;
  }
  .menu.show {
    opacity: 1;
    transform: scale(1);
    pointer-events: auto;
  }
  .menu a {
    background: #111;
    border: 1px solid #0ff;
    color: #0ff;
    width: 46px;
    height: 46px;
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    box-shadow: 0 0 8px #0ff inset, 0 0 12px #0ff;
    transition: 0.25s ease;
    font-size: 20px;
    text-decoration: none;
  }
  .menu a:hover {
    background: #0ff;
    color: #000;
    box-shadow: 0 0 12px #0ff, 0 0 20px #0ff;
    transform: scale(1.15);
  }
</style>

<script>
  const fab = document.getElementById("fab");
  const menu = document.getElementById("menu");
  fab.addEventListener("click", (e) => {
    e.stopPropagation();
    fab.classList.toggle("active");
    menu.classList.toggle("show");
  });
  document.addEventListener("click", () => {
    fab.classList.remove("active");
    menu.classList.remove("show");
  });
</script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
<style>
.navigation {
	position: fixed;
	bottom: 0;
	left: 0;
	width: 100%;
	height: 70px;
	background: #1e1e2f; 
	display: flex;
	justify-content: center;
	align-items: center;
	border-radius: 20px 20px 0 0;
	box-shadow: 0 -3px 25px rgba(0,0,0,0.4);
	z-index: 1000;
}

.navigation ul {
	width: 350px;
	display: flex;
	justify-content: space-between;
}

.navigation ul li {
	list-style: none;
	position: relative;
	width: 70px;
	height: 60px;
	z-index: 2;
}

.navigation ul li a {
	text-decoration: none;
	color: #aaa;
	position: relative;
	display: flex;
	justify-content: center;
	align-items: center;
	width: 100%;
	height: 100%;
	transition: 0.3s ease;
}

.navigation ul li a:hover {
	color: #fff;
}

.navigation ul li a .icon {
	position: relative;
	background: transparent;
	display: block;
	width: 55px;
	height: 55px;
	text-align: center;
	line-height: 65px;
	border-radius: 50%;
	color: #aaa;
	font-size: 1.6em;
	transition: 0.4s ease;
}

.navigation ul li.active a .icon {
	background: linear-gradient(135deg, #6c5ce7, #00cec9);
	color: #fff;
	transform: translateY(-27px);
	box-shadow: 0 0 15px rgba(108,92,231,0.8),
				0 0 25px rgba(0,206,201,0.6);
}

.navigation ul li a .icon:before {
	content: '';
	position: absolute;
	top: 10px;
	left: 0;
	width: 100%;
	height: 100%;
	background: linear-gradient(135deg, #6c5ce7, #00cec9);
	border-radius: 50%;
	filter: blur(8px);
	opacity: 0;
	transition: 0.4s ease;
}

.navigation ul li.active a .icon:before {
	opacity: 0.6;
}
</style>

<body>
<?php if (session()->has('userid')): ?>
<div class='navigation'>
	<ul>
		<li class="list active" style="--clr:#f44336"><a href="<?= site_url('dashboard') ?>"><span class="icon">
					<ion-icon name="home-outline"></ion-icon>
				</span></a></li>
		<li class="list" style="--clr:#ffa117"><a href="<?= site_url('keys/generate') ?>"><span class="icon">
					<ion-icon name="person-outline"></ion-icon>
				</span></a></li>
		<li class="list" style="--clr:#b145e9"><a href="<?= site_url('keys') ?>"><span class="icon">
					<ion-icon name="settings-outline"></ion-icon>
				</span></a></li>
		<div class="indicator"></div>
	</ul>
</div>
      <?php endif; ?>

<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<script>
console.clear();
const list = document.querySelectorAll('.list');

const currentUrl = window.location.pathname;

list.forEach(item => {
  const link = item.querySelector("a").getAttribute("href");
  const url = new URL(link, window.location.origin).pathname;

  if (currentUrl === url) {
    item.classList.add("active");
  } else {
    item.classList.remove("active");
  }
});

list.forEach(item => item.addEventListener('click', function(e){
  list.forEach(li => li.classList.remove('active'));
  e.currentTarget.classList.add('active');
}));
</script>
</header>