<?php
// msgStatus_fixed.php - fixed modern welcome card with verification badge
// Place this include where you want the welcome/flash messages to appear.
// It shows flash messages (danger/success/warning) if they exist, then shows a compact welcome card when getName($user) is available.
?>
<style>
/* Compact modern welcome card + verification badge */
@keyframes fadeSlideIn { from {opacity:0; transform:translateY(-8px);} to {opacity:1; transform:translateY(0);} }
@keyframes fadeTextIn { from {opacity:0; transform:translateY(6px);} to {opacity:1; transform:translateY(0);} }

.welcome-card {
  font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif;
  background: linear-gradient(135deg,#6366f1 0%,#3b82f6 100%);
  color: #fff;
  padding: 12px;
  border-radius: 12px;
  box-shadow: 0 8px 20px rgba(0,0,0,0.12);
  display: flex;
  gap: 12px;
  align-items: center;
  max-width: 420px;
  animation: fadeSlideIn 0.6s ease-out forwards;
  opacity: 0;
  transform: translateY(-8px);
}

.welcome-icon{
  width:44px;
  height:44px;
  border-radius:10px;
  background: rgba(255,255,255,0.12);
  display:flex;
  align-items:center;
  justify-content:center;
  flex:0 0 44px;
}

.welcome-icon svg{ width:28px; height:28px; fill:white; opacity:0.95; }

.welcome-text{
  flex:1;
  opacity:0;
  animation: fadeTextIn 1.0s ease-out 0.3s forwards;
  min-width:0;
}

.welcome-title{
  margin:0;
  font-size:15px;
  font-weight:600;
  display:flex;
  align-items:center;
  gap:6px;
  line-height:1;
}

.welcome-sub{
  margin:4px 0 0 0;
  font-size:12px;
  color: rgba(255,255,255,0.9);
}

/* verification badge style */
.verified-badge{
  width:16px;
  height:16px;
  display:inline-block;
  vertical-align:middle;
  margin-left:6px;
  flex:0 0 16px;
}
.verified-badge svg{ width:16px; height:16px; display:block; }
</style>

<?php if (session()->getFlashdata('msgDanger')) : ?>
    <div class="alert alert-danger fade show" role="alert">
        <?= session()->getFlashdata('msgDanger') ?>
    </div>
<?php elseif (session()->getFlashdata('msgSuccess')) : ?>
    <div class="alert alert-success fade show" role="alert">
        <?= session()->getFlashdata('msgSuccess') ?>
    </div>
<?php elseif (session()->getFlashdata('msgWarning')) : ?>
    <div class="alert alert-warning fade show" role="alert">
        <?= session()->getFlashdata('msgWarning') ?>
    </div>
<?php endif; ?>

<?php
// Show compact welcome if getName and $user exist or if getName returns non-empty string
$displayName = '';
if (function_exists('getName')) {
    // Avoid calling getName twice in case it has side effects
    $displayName = getName($user);
}
if (!empty($displayName)) :
?>
  <div class="welcome-card" role="status" aria-live="polite" aria-atomic="true">
    <div class="welcome-icon" aria-hidden="true">
      <!-- user SVG icon -->
      <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M12 12c2.8 0 5-2.2 5-5s-2.2-5-5-5-5 2.2-5 5 2.2 5 5 5zm0 2c-3.6 0-10 1.8-10 5v2h20v-2c0-3.2-6.4-5-10-5z"/></svg>
    </div>
    <div class="welcome-text">
      <p class="welcome-title">Welcome <?= htmlspecialchars($displayName, ENT_QUOTES, 'UTF-8') ?>
        <span class="verified-badge" title="Verified">
          <!-- verification badge similar to Twitter/Facebook -->
          <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
            <circle cx="12" cy="12" r="10" fill="#1DA1F2"/>
            <path d="M9.6 13.9l-1.9-1.9a0.7 0.7 0 0 0-1 1l2.4 2.4c.27.27.7.27.97 0l6-6a0.7 0.7 0 1 0-1-1l-5.5 5.5z" fill="#fff"/>
          </svg>
        </span>
      </p>
      <small class="welcome-sub">You are successfully logged in</small>
    </div>
  </div>
<?php endif; ?>
