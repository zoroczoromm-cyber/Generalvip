<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<style>
  html, body { 
    height:100%; margin:0; 
    font-family: 'Segoe UI', sans-serif;
    color:#fff;
  }
  #particles-js {
    position: fixed;
    inset:0;
    width:100%; height:100%;
    background:#0d1117;
    z-index:-1;
  }

  .dashboard {
    position: relative;
    z-index: 1;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: 2rem;
  }

  .grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr); /* دائرتين بالصف */
    gap: 2rem;
    width: 100%;
    max-width: 600px; /* عرض أصغر حتى تكون مرتبة */
  }

  .circle-card {
    background: rgba(255,255,255,0.06);
    border: 1px solid rgba(88,166,255,0.25);
    border-radius: 50%;
    width: 140px;
    height: 140px;
    margin: auto;
    backdrop-filter: blur(12px);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    transition: transform .3s ease, box-shadow .3s ease;
  }
  .circle-card:hover {
    transform: scale(1.08);
    box-shadow: 0 0 20px rgba(88,166,255,0.4);
  }

  .circle-card svg {
    width: 28px;
    height: 28px;
    margin-bottom: 6px;
    fill: #58a6ff;
  }
  .circle-card .value {
    font-size: 1.1rem;
    font-weight: bold;
  }
  .circle-card .label {
    font-size: 0.8rem;
    opacity: 0.8;
  }
  html,body { height:100%; margin:0; }
  #particles-js {
    position: fixed;
    top:0; left:0; right:0; bottom:0;
    width:100%; height:100%;
    background-color:#0d1117; 
    z-index: -1;
  }
  
.card { background:rgba(22,27,34,0.85); border:1px solid rgba(88,166,255,0.3); border-radius:12px; color:#e6edf3; }
.card-header { background:rgba(88,166,255,0.1); border-bottom:1px solid rgba(88,166,255,0.3); color:#58a6ff; font-weight:bold; text-shadow:0 0 6px #58a6ff; }
table.table { color:#e6edf3 !important; }
table.table thead th { background:rgba(88,166,255,0.12) !important; color:#58a6ff !important; text-shadow:0 0 6px #58a6ff; }
table.table tbody tr:nth-child(even) { background:rgba(88,166,255,0.05) !important; }
table.table tbody tr:nth-child(odd) { background:rgba(22,27,34,0.6) !important; }
table.table tbody tr:hover { background:rgba(88,166,255,0.15) !important; }

/* widgets grid */
.dashboard-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:14px; margin-bottom:20px; }
.widget { background:rgba(22,27,34,0.88); border:1px solid rgba(88,166,255,0.25); border-radius:12px; padding:16px; text-align:center; box-shadow:0 0 14px rgba(0,0,0,0.3); }
.widget svg { width:32px; height:32px; margin-bottom:6px; fill:#58a6ff; }
.widget .title { color:#58a6ff; font-weight:600; font-size:14px; margin-bottom:4px; }
.widget .val { font-size:1.2rem; font-weight:700; color:#fff; }
  .content {
    position: relative;
    z-index: 1;
    padding: 2rem;
  }

  
  .card {
    background: rgba(20, 25, 34, 0.85);
    border: 1px solid rgba(0, 255, 255, 0.2);
    border-radius: 15px;
    box-shadow: 0 0 20px rgba(0,255,255,0.2);
    transition: transform 0.3s ease;
    color: #fff;
  }
  .card:hover {
    transform: translateY(-5px);
    box-shadow: 0 0 25px rgba(0,255,255,0.4);
  }

  .card-header {
    background: linear-gradient(90deg, #0ff2, #0ff4);
    color: #0ff;
    font-weight: 700;
    letter-spacing: 1px;
    border-bottom: 1px solid rgba(0,255,255,0.4);
  }

 
  .form-control, .form-select {
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(0,255,255,0.3);
    color: #fff;
    border-radius: 10px;
    padding: 10px 15px;
    transition: 0.3s;
  }
  .form-control:focus, .form-select:focus {
    border-color: #0ff;
    box-shadow: 0 0 10px #0ff;
    background: rgba(0,255,255,0.1);
  }
/* الهيدر تبع الكارد */
.card-header.bg-primary {
  background: linear-gradient(90deg, #0ff2, #0ff4) !important;
  color: #0ff !important;
  border-bottom: 1px solid rgba(0,255,255,0.4) !important;
  text-shadow: 0 0 6px #0ff;
}

/* الأزرار */
.btn-primary {
  background: #0ff !important;
  border: 1px solid #0ff !important;
  color: #000 !important;
  font-weight: bold;
  transition: 0.3s;
}
.btn-primary:hover {
  background: #00e6e6 !important;
  box-shadow: 0 0 15px #0ff, 0 0 25px #0ff;
  color: #000 !important;
}
 
  .btn {
    border-radius: 10px;
    font-weight: bold;
    transition: all 0.3s ease;
  }
  .btn-outline-dark {
    border: 1px solid #0ff;
    color: #0ff;
  }
  .btn-outline-dark:hover {
    background: #0ff;
    color: #000 !important;
    box-shadow: 0 0 15px #0ff, 0 0 25px #0ff;
  }

  
  .table-bordered td, .table-bordered th {
    border: 1px solid #0ff !important;
  }
  .table td, .table th {
    border-color: #0ff !important;
    color: #fff;
  }
  .table th {
    background: rgba(0,255,255,0.15);
    color: #0ff;
    font-weight: 600;
    text-transform: uppercase;
  }
  .table td:nth-child(3) {
    color: #0ff !important;
    font-weight: 600;
  }
  .table tbody tr:hover {
    background: rgba(0,255,255,0.05);
    box-shadow: inset 0 0 10px rgba(0,255,255,0.2);
  }

 
  .badge {
    border-radius: 6px;
    padding: 4px 8px;
    font-weight: 600;
    background: rgba(0,255,255,0.15);
    color: #0ff;
    border: 1px solid rgba(0,255,255,0.3);
  }
  .badge.text-danger { color:#f85149; border-color:#f85149; background:rgba(248,81,73,0.15);}
  .badge.text-success { color:#3fb950; border-color:#3fb950; background:rgba(63,185,80,0.15);}
</style>

<?= $this->include('Layout/msgStatus') ?>

<div id="particles-js"></div>
<div class="row justify-content-center">
    <div class="row">
        <div class="col-lg-12">
            <?= $this->include('Layout/msgStatus') ?>
        </div>
        <div class="col-lg-12">
            <div class="card shadow-sm">
                <div class="card-header bg-dark text-white">
                    <div class="row">
                        <div class="col pt-1">
                           <strong> Keys Registered </strong>
                            
                            
                        </div>
                        <div class="col text-end">

                        <div class="float-right">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="bi bi-file-arrow-down-fill"></i>Open Menu
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end dropdown-menu-lg-start" aria-labelledby="navbarDropdown">
                                 <div class="card-header bg-light text-black h6 p-3">
                                     
                                     
                                        <li>
                                            <a class="dropdown-item" href="<?= site_url('keyz/generates') ?>">
                                                <i class="bi bi-file-plus-fill"></i>&nbsp; <button type="button" class="btn btn-secondary">Generate</button>
                                            
                                            </a>
                                           
                                        </li>
                                         <br>
                                        <li>
                                            <a class="dropdown-item" href="<?= site_url('keyz/alter') ?>">
                                                <i class="bi bi-shield-x"></i>&nbsp; <button class="btn btn-secondary">Delete Expired</button>
                                            
                                            </a>
                                        </li>
                                         <br>
                                        <li>
                                        <a class="dropdown-item" href="<?= site_url('keyz/deleteAll')  ?>">
                                            <i class="bi bi-trash-fill"></i>&nbsp;  <button class="btn btn-secondary">Delete All</button>
                                        </a>
                                    </li>
                                     <br>
                                    <li>
                                        <a class="dropdown-item" href="<?= site_url('keyz/start')  ?>">
                                            <i class="bi bi-backspace-reverse-fill"></i> &nbsp; <button class="btn btn-secondary">Delete Not Used</button>
                                        </a>
                                    </li>
                                     <br>
                                     </li>
                                    
                                    <a class="dropdown-item" href="<?= site_url('keyz/resetAll') ?>">
                                          <i class="bi bi-bootstrap-reboot"></i>&nbsp; <button class="btn btn-secondary">Reset All Key</button>
                                      </a>
                                  </li>
                                
                                    <li>
                                        <a class="dropdown-item" href="<?= site_url('keyz/download/all')  ?>">
                                            <i class="bi bi-download"></i> &nbsp;<button class="btn btn-secondary">Download All Key </button>
                                        </a>
                                    </li>
                                    
                                 
                                    
                                </ul>
                            </li>
                        </ul>
                    </div>
                       
                        </div>
                    </div>
                </div>
                
                <div class="card-body">
                    <?php if ($keyzlistz) : ?>
                        <div class="table-responsive">
                            <table id="datatable" class="table table-bordered table-hover text-center" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Game</th>
                                        <th>User Keys</th>
                                        <th>Devices</th>
                                        <th>Duration</th>
                                        <th>Expired</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    <?php else : ?>
                        <p class="text-center">Nothing keys to show</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('css') ?>
<?= link_tag("https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css") ?>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js") ?>

<?= script_tag("https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js") ?>
<script>
    $(document).ready(function() {
        var table = $('#datatable').DataTable({
            processing: true,
            serverSide: true,
            order: [
                [0, "desc"]
            ],
            ajax: "<?= site_url('keyz/api') ?>",
            columns: [{
                    data: 'id',
                    name: 'id_keyz'
                },
                {
                    data: 'game',
                },
                {
                    data: 'user_key',
                    render: function(data, type, row, meta) {
                        var is_valid = (row.status == 'Active') ? "text-success" : "text-danger";
                        return `<span class="${is_valid} ">${(row.user_key ? row.user_key : '&mdash;')}</span> `;
                    }
                },
                {
                    data: 'devices',
                    render: function(data, type, row, meta) {
                        var totalDevice = (row.devices ? row.devices : 0);
                        return `<span id="devMax-${row.user_key}">${totalDevice}/${row.max_devices}</span>`;
                    }
                },
                {
                    data: 'duration',
                    render: function(data, type, row, meta) {
                        return row.duration;
                    }
                },
                {
                    data: 'expired',
                    name: 'expired_date',
                    render: function(data, type, row, meta) {
                        return row.expired ? `<span class="badge text-dark">${row.expired}</span>` : '(not started yet)';
                    }
                },
                {
                    data: null,
                    render: function(data, type, row, meta) {
                        var btnReset = `<button class="btn btn-outline-warning btn-sm" onclick="resetUserKeyz('${row.user_key}')"
                        data-bs-toggle="tooltip" data-bs-placement="left" title="Reset key?"><i class="bi bi-bootstrap-reboot"></i></button>`;
                        
                        var btnEdits = `<a href="${window.location.origin}/keyz/${row.id}" class="btn btn-outline-dark btn-sm"
                        data-bs-toggle="tooltip" data-bs-placement="left" title="Edit key information?"><i class="bi bi-gear"></i></a>`;
                        
                        
                        var btnDelete = `<button class="btn btn-outline-danger btn-sm" onclick="deleteKeyz('${row.user_key}')"
                        data-bs-toggle="tooltip" data-bs-placement="left" title="Delete Key?"><i class="bi bi-trash"></i></button>`;
                        
                        
                        return `<div class="d-grid gap-2 d-md-block">${btnReset} ${btnEdits} ${btnDelete}</div>`;
                    }
                }
            ]
        });

        $("#blur-out").click(function() {
            if ($(".keyBlur").hasClass("key-sensi")) {
                $(".keyBlur").removeClass("key-sensi");
                $("#blur-out").html(`<i class="bi bi-eye"></i>`);
            } else {
                $(".keyBlur").addClass("key-sensi");
                $("#blur-out").html(`<i class="bi bi-eye-slash"></i>`);
            }
        });
    });

function deleteKeyz(keyz) {
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete'
        }).then((result) => {
            if (result.isConfirmed) {
                Toast.fire({
                    icon: 'info',
                    title: 'Please wait...'
                })

                var base_url = window.location.origin;
                var api_url = `${base_url}/keyz/delete`;
                $.getJSON(api_url, {
                        userkey: keyz,
                        delete: 1
                    },
                    function(data, textStatus, jqXHR) {
                        if (textStatus == 'success') {
                            if (data.registered) {
                                if (data.delete) {
                                    $(`#devMax-${keyz}`).html(`0/${data.devices_max}`);
                                    Swal.fire(
                                        'Deleted!',
                                        'Key has been deleted Successfully.',
                                        'success'
                                    )
                                } else {
                                    Swal.fire(
                                        'Failed!',
                                        data.devices_total ? "You don't have any access to this user." : "Only Admin can delete the user.",
                                        data.devices_total ? 'error' : 'error'
                                        
                                    )
                                }
                            } else {
                                Swal.fire(
                                    'Failed!',
                                    "User key no longer exists.",
                                    'error'
                                )
                            }
                        }
                    }
                );
            }
        });
    }
    function resetUserKeyz(keyz) {
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, reset'
        }).then((result) => {
            if (result.isConfirmed) {
                Toast.fire({
                    icon: 'info',
                    title: 'Please wait...'
                })

                var base_url = window.location.origin;
                var api_url = `${base_url}/keyz/reset`;
                $.getJSON(api_url, {
                        userkey: keyz,
                        reset: 1
                    },
                    function(data, textStatus, jqXHR) {
                        if (textStatus == 'success') {
                            if (data.registered) {
                                if (data.reset) {
                                    $(`#devMax-${keyz}`).html(`0/${data.devices_max}`);
                                    Swal.fire(
                                        'Reset!',
                                        'Your device key has been reset.',
                                        'success'
                                    )
                                } else {
                                    Swal.fire(
                                        'Failed!',
                                        data.devices_total ? "You don't have any access to this user." : "User key devices already reset.",
                                        data.devices_total ? 'error' : 'warning'
                                    )
                                }
                            } else {
                                Swal.fire(
                                    'Failed!',
                                    "User key no longer exists.",
                                    'error'
                                )
                            }
                        }
                    }
                );
            }
        });
    }
</script>

<script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
<script>
  particlesJS("particles-js", {
    "particles": {
      "number": { "value": 100, "density": { "enable": true, "value_area": 800 } },
      "color": { "value": "#58a6ff" },
      "shape": { "type": "circle" },
      "opacity": { "value": 0.5 },
      "size": { "value": 3, "random": true },
      "line_linked": { "enable": true, "distance": 150, "color": "#58a6ff", "opacity": 0.4, "width": 1 },
      "move": { "enable": true, "speed": 2, "direction": "none", "out_mode": "out" }
    },
    "interactivity": {
      "events": { "onhover": { "enable": true, "mode": "grab" }, "onclick": { "enable": true, "mode": "push" } },
      "modes": { "grab": { "distance": 140, "line_linked": { "opacity": 1 } }, "push": { "particles_nb": 4 } }
    },
    "retina_detect": true
  });
</script>
<?= $this->endSection() ?>