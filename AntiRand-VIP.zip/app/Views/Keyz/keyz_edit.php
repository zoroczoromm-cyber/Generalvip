<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<style>
  html, body { 
    height:100%; margin:0; 
    font-family: 'Segoe UI', sans-serif;
    color:#fff;
  }
  #particles-js {
    position: fixed;
    inset:0;
    width:100%; height:100%;
    background:#0d1117;
    z-index:-1;
  }

  .dashboard {
    position: relative;
    z-index: 1;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: 2rem;
  }

  .grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr); /* دائرتين بالصف */
    gap: 2rem;
    width: 100%;
    max-width: 600px; /* عرض أصغر حتى تكون مرتبة */
  }

  .circle-card {
    background: rgba(255,255,255,0.06);
    border: 1px solid rgba(88,166,255,0.25);
    border-radius: 50%;
    width: 140px;
    height: 140px;
    margin: auto;
    backdrop-filter: blur(12px);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    transition: transform .3s ease, box-shadow .3s ease;
  }
  .circle-card:hover {
    transform: scale(1.08);
    box-shadow: 0 0 20px rgba(88,166,255,0.4);
  }

  .circle-card svg {
    width: 28px;
    height: 28px;
    margin-bottom: 6px;
    fill: #58a6ff;
  }
  .circle-card .value {
    font-size: 1.1rem;
    font-weight: bold;
  }
  .circle-card .label {
    font-size: 0.8rem;
    opacity: 0.8;
  }
  html,body { height:100%; margin:0; }
  #particles-js {
    position: fixed;
    top:0; left:0; right:0; bottom:0;
    width:100%; height:100%;
    background-color:#0d1117; 
    z-index: -1;
  }
  
.card { background:rgba(22,27,34,0.85); border:1px solid rgba(88,166,255,0.3); border-radius:12px; color:#e6edf3; }
.card-header { background:rgba(88,166,255,0.1); border-bottom:1px solid rgba(88,166,255,0.3); color:#58a6ff; font-weight:bold; text-shadow:0 0 6px #58a6ff; }
table.table { color:#e6edf3 !important; }
table.table thead th { background:rgba(88,166,255,0.12) !important; color:#58a6ff !important; text-shadow:0 0 6px #58a6ff; }
table.table tbody tr:nth-child(even) { background:rgba(88,166,255,0.05) !important; }
table.table tbody tr:nth-child(odd) { background:rgba(22,27,34,0.6) !important; }
table.table tbody tr:hover { background:rgba(88,166,255,0.15) !important; }

/* widgets grid */
.dashboard-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:14px; margin-bottom:20px; }
.widget { background:rgba(22,27,34,0.88); border:1px solid rgba(88,166,255,0.25); border-radius:12px; padding:16px; text-align:center; box-shadow:0 0 14px rgba(0,0,0,0.3); }
.widget svg { width:32px; height:32px; margin-bottom:6px; fill:#58a6ff; }
.widget .title { color:#58a6ff; font-weight:600; font-size:14px; margin-bottom:4px; }
.widget .val { font-size:1.2rem; font-weight:700; color:#fff; }
  .content {
    position: relative;
    z-index: 1;
    padding: 2rem;
  }

  
  .card {
    background: rgba(20, 25, 34, 0.85);
    border: 1px solid rgba(0, 255, 255, 0.2);
    border-radius: 15px;
    box-shadow: 0 0 20px rgba(0,255,255,0.2);
    transition: transform 0.3s ease;
    color: #fff;
  }
  .card:hover {
    transform: translateY(-5px);
    box-shadow: 0 0 25px rgba(0,255,255,0.4);
  }

  .card-header {
    background: linear-gradient(90deg, #0ff2, #0ff4);
    color: #0ff;
    font-weight: 700;
    letter-spacing: 1px;
    border-bottom: 1px solid rgba(0,255,255,0.4);
  }

 
  .form-control, .form-select {
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(0,255,255,0.3);
    color: #fff;
    border-radius: 10px;
    padding: 10px 15px;
    transition: 0.3s;
  }
  .form-control:focus, .form-select:focus {
    border-color: #0ff;
    box-shadow: 0 0 10px #0ff;
    background: rgba(0,255,255,0.1);
  }
/* الهيدر تبع الكارد */
.card-header.bg-primary {
  background: linear-gradient(90deg, #0ff2, #0ff4) !important;
  color: #0ff !important;
  border-bottom: 1px solid rgba(0,255,255,0.4) !important;
  text-shadow: 0 0 6px #0ff;
}

/* الأزرار */
.btn-primary {
  background: #0ff !important;
  border: 1px solid #0ff !important;
  color: #000 !important;
  font-weight: bold;
  transition: 0.3s;
}
.btn-primary:hover {
  background: #00e6e6 !important;
  box-shadow: 0 0 15px #0ff, 0 0 25px #0ff;
  color: #000 !important;
}
 
  .btn {
    border-radius: 10px;
    font-weight: bold;
    transition: all 0.3s ease;
  }
  .btn-outline-dark {
    border: 1px solid #0ff;
    color: #0ff;
  }
  .btn-outline-dark:hover {
    background: #0ff;
    color: #000 !important;
    box-shadow: 0 0 15px #0ff, 0 0 25px #0ff;
  }

  
  .table-bordered td, .table-bordered th {
    border: 1px solid #0ff !important;
  }
  .table td, .table th {
    border-color: #0ff !important;
    color: #fff;
  }
  .table th {
    background: rgba(0,255,255,0.15);
    color: #0ff;
    font-weight: 600;
    text-transform: uppercase;
  }
  .table td:nth-child(3) {
    color: #0ff !important;
    font-weight: 600;
  }
  .table tbody tr:hover {
    background: rgba(0,255,255,0.05);
    box-shadow: inset 0 0 10px rgba(0,255,255,0.2);
  }

 
  .badge {
    border-radius: 6px;
    padding: 4px 8px;
    font-weight: 600;
    background: rgba(0,255,255,0.15);
    color: #0ff;
    border: 1px solid rgba(0,255,255,0.3);
  }
  .badge.text-danger { color:#f85149; border-color:#f85149; background:rgba(248,81,73,0.15);}
  .badge.text-success { color:#3fb950; border-color:#3fb950; background:rgba(63,185,80,0.15);}
</style>

<?= $this->include('Layout/msgStatus') ?>

<div id="particles-js"></div>
<?php
// $exCount = 0;
// if ($key->devices) {
//     $ex = explode(',', reduce_multiples($key->devices, ",", true));
//     $listDevice = "";
//     foreach ($ex as $ld) {
//         $listDevice .= "$ld\n";
//     }
//     $exCount = count($ex);
// }
?>

<div class="row pb-5 justify-content-center">
    <div class="col-lg-8">
        <?= $this->include('Layout/msgStatus') ?>

    </div>
    <div class="col-lg-8 mb-3">
        <div class="card">
            <div class="card-header bg-dark text-white">
                <div class="row">
                    <div class="col pt-1">
                        Key Information
                    </div>
                    <div class="col">
                        <div class="text-end">
                            <a class="btn btn-sm btn-outline-light" href="<?= site_url('keyz/generates') ?>"><i class="bi bi-person-plus"></i></a>
                            <a class="btn btn-sm btn-outline-light" href="<?= site_url('keyz') ?>"><i class="bi bi-people"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?= form_open('keyz/keyz_edit') ?>

                <div class="row">
                    <input type="hidden" name="id_keyz" value="<?= $key->id_keyz ?>">
                    <?php if ($user->level == 1) : ?>
                        <div class="col-lg-6 mb-3">
                            <label for="game" class="form-label">Games</label>
                            <input type="text" name="game" id="game" class="form-control" placeholder="RandomKey" aria-describedby="help-game" value="<?= old('game') ?: $key->game ?>">
                            <?php if ($validation->hasError('game')) : ?>
                                <small id="help-game" class="text-danger"><?= $validation->getError('game') ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label for="user_key" class="form-label">User Key</label>
                            <input type="text" name="user_key" id="user_key" class="form-control" placeholder="RandomKey" aria-describedby="help-user_key" value="<?= old('user_key') ?: $key->user_key ?>">
                            <?php if ($validation->hasError('user_key')) : ?>
                                <small id="help-user_key" class="text-danger"><?= $validation->getError('user_key') ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label for="duration" class="form-label">Duration <small class="text-muted">(in days)</small></label>
                            <input type="number" name="duration" id="duration" class="form-control" placeholder="3" aria-describedby="help-duration" value="<?= old('duration') ?: $key->duration ?>">
                            <?php if ($validation->hasError('duration')) : ?>
                                <small id="help-duration" class="text-danger"><?= $validation->getError('duration') ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label for="max_devices" class="form-label">Max Devices</label>
                            <input type="number" name="max_devices" id="max_devices" class="form-control" placeholder="3" aria-describedby="help-max_devices" value="<?= old('max_devices') ?: $key->max_devices ?>">
                            <?php if ($validation->hasError('max_devices')) : ?>
                                <small id="help-max_devices" class="text-danger"><?= $validation->getError('max_devices') ?></small>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <div class="col-md-6 mb-2" id="col-status">
                        <label for="status" class="form-label">Status</label>
                        <?php $sel_status = ['' => '&mdash; Select Status &mdash;', '0' => 'Banned/Block', '1' => 'Active',]; ?>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'status', 'id' => 'status'], $sel_status, $key->status) ?>
                        <?php if ($validation->hasError('status')) : ?>
                            <small id="help-status" class="text-danger"><?= $validation->getError('status') ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="registrator" class="form-label">Registrator</label>
                        <input type="text" name="registrator" id="registrator" class="form-control" placeholder="nata" aria-describedby="help-registrator" value="<?= old('registrator') ?: $key->registrator ?>">
                        <?php if ($validation->hasError('registrator')) : ?>
                            <small id="help-registrator" class="text-danger"><?= $validation->getError('registrator') ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="expired_date" class="form-label">Expired <?= !$key->expired_date ? '(Not started yet)' : ''  ?></label>
                        <input type="text" name="expired_date" id="expired_date" class="form-control" placeholder="<?= $time::now() ?>" aria-describedby="help-expired_date" value="<?= old('expired_date') ?: $key->expired_date ?>">
                        <?php if ($validation->hasError('expired_date')) : ?>
                            <small id="help-expired_date" class="text-danger"><?= $validation->getError('expired_date') ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label for="devices" class="form-label">Devices <span class="bg-dark text-white px-1 rounded maxDev"><?= $key_info->total ?>/<?= $key->max_devices ?></span> <small class="text-muted">(Separately with enter)</small></label>
                        <textarea class="form-control" name="devices" id="devices" rows="<?= ($key_info->total > $key->max_devices) ? 3 : $key_info->total ?>"><?= old('devices') ?: ($key_info->total ? $key_info->devices : '') ?></textarea>
                        <?php if ($validation->hasError('devices')) : ?>
                            <small id="help-devices" class="text-danger"><?= $validation->getError('devices') ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="col-lg-6">
                        <button class="btn btn-outline-dark btnUpdate" disabled>Update User Key</button>
                    </div>
                    <?= form_close() ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script>
    $(document).ready(function() {
        var level = "<?= $user->level ?>";
        if (level != 1) $("#registrator, #expired_date, #devices").attr('disabled', true);
        $("input, select, textarea").change(function() {
            $(".btnUpdate").attr('disabled', false);
        });
    });
    var total = "<?= $key_info->total ?>";
    $("#max_devices").change(function() {
        $(".maxDev").html(total + '/' + $(this).val());
        $("#devices").attr('rows', $(this).val());
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
<script>
  particlesJS("particles-js", {
    "particles": {
      "number": { "value": 100, "density": { "enable": true, "value_area": 800 } },
      "color": { "value": "#58a6ff" },
      "shape": { "type": "circle" },
      "opacity": { "value": 0.5 },
      "size": { "value": 3, "random": true },
      "line_linked": { "enable": true, "distance": 150, "color": "#58a6ff", "opacity": 0.4, "width": 1 },
      "move": { "enable": true, "speed": 2, "direction": "none", "out_mode": "out" }
    },
    "interactivity": {
      "events": { "onhover": { "enable": true, "mode": "grab" }, "onclick": { "enable": true, "mode": "push" } },
      "modes": { "grab": { "distance": 140, "line_linked": { "opacity": 1 } }, "push": { "particles_nb": 4 } }
    },
    "retina_detect": true
  });
</script>
<?= $this->endSection() ?>