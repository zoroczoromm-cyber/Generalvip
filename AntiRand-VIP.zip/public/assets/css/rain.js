// الحصول على عنصر الـ Canvas
let canvas = document.getElementById("rainCanvas");
let ctx = canvas.getContext("2d");

// ضبط حجم الـ Canvas ليملأ الشاشة
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

// إنشاء مصفوفة لتخزين القطرات
let drops = [];
for (let i = 0; i < 100; i++) { // عدد القطرات
    drops.push({
        x: Math.random() * canvas.width, // موضع أفقي عشوائي
        y: Math.random() * canvas.height, // موضع عمودي عشوائي
        speed: Math.random() * 3 + 2, // سرعة السقوط
        length: Math.random() * 15 + 10 // طول القطرات
    });
}

// دالة رسم المطر
function drawRain() {
    ctx.clearRect(0, 0, canvas.width, canvas.height); // مسح الرسم السابق
    ctx.strokeStyle = "rgba(255, 255, 255, 0.6)"; // لون القطرات
    ctx.lineWidth = 2;
    ctx.beginPath();
    
    for (let i = 0; i < drops.length; i++) {
        let d = drops[i];
        ctx.moveTo(d.x, d.y);
        ctx.lineTo(d.x, d.y + d.length);
    }
    ctx.stroke();
    
    for (let i = 0; i < drops.length; i++) {
        drops[i].y += drops[i].
