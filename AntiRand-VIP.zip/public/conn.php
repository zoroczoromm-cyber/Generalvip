<?php

$servername = "localhost";
$username = "vippane1_3KRAB";
$password = "Mohamed1#@1";
$dbname = "vippane1_3KRAB";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>